<?php
// ============================================================
// ERP System — Planning: Board (Concept port from Firebase)
// Keeps existing UI theme/colors. Planning module only.
// ============================================================
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth_check.php';

$db = getDB();

// Ensure department support for planning rows.
try { $db->query("ALTER TABLE planning ADD COLUMN department VARCHAR(80) NOT NULL DEFAULT 'general' AFTER notes"); } catch (Exception $e) {}
try { $db->query("ALTER TABLE planning ADD COLUMN extra_data LONGTEXT NULL AFTER department"); } catch (Exception $e) {}
try { $db->query("ALTER TABLE planning ADD COLUMN job_no VARCHAR(60) NULL AFTER id"); } catch (Exception $e) {}
try { $db->query("ALTER TABLE planning ADD COLUMN sequence_order INT NOT NULL DEFAULT 0 AFTER extra_data"); } catch (Exception $e) {}

// Config table for planning board columns (rename/type/reorder).
@$db->query("CREATE TABLE IF NOT EXISTS planning_board_columns (
  id INT AUTO_INCREMENT PRIMARY KEY,
  department VARCHAR(80) NOT NULL,
  col_key VARCHAR(80) NOT NULL,
  col_label VARCHAR(120) NOT NULL,
  col_type VARCHAR(20) NOT NULL DEFAULT 'Text',
  sort_order INT NOT NULL DEFAULT 0,
  UNIQUE KEY uniq_dept_col (department, col_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$csrfToken = generateCSRF();

$department = trim((string)($_GET['department'] ?? 'label-printing'));
if ($department === '') $department = 'label-printing';

$defaultColumns = [
    ['key' => 'sn', 'label' => 'S.N', 'type' => 'Number', 'sort' => 1],
  ['key' => 'printing_planning', 'label' => 'Status', 'type' => 'Status', 'sort' => 2],
  ['key' => 'name', 'label' => 'Job Name', 'type' => 'Text', 'sort' => 3],
  ['key' => 'priority', 'label' => 'Priority', 'type' => 'Priority', 'sort' => 4],
  ['key' => 'order_date', 'label' => 'Order Date', 'type' => 'Date', 'sort' => 5],
  ['key' => 'dispatch_date', 'label' => 'Dispatch Date', 'type' => 'Date', 'sort' => 6],
  ['key' => 'plate_no', 'label' => 'Plate No', 'type' => 'Text', 'sort' => 7],
  ['key' => 'size', 'label' => 'Size', 'type' => 'Text', 'sort' => 8],
  ['key' => 'repeat', 'label' => 'Repeat', 'type' => 'Text', 'sort' => 9],
  ['key' => 'material', 'label' => 'Material', 'type' => 'Text', 'sort' => 10],
  ['key' => 'paper_size', 'label' => 'Paper Size', 'type' => 'Text', 'sort' => 11],
  ['key' => 'die', 'label' => 'Die', 'type' => 'Text', 'sort' => 12],
  ['key' => 'allocate_mtrs', 'label' => 'MTRS', 'type' => 'Number', 'sort' => 13],
  ['key' => 'qty_pcs', 'label' => 'QTY', 'type' => 'Number', 'sort' => 14],
  ['key' => 'core_size', 'label' => 'Core', 'type' => 'Text', 'sort' => 15],
  ['key' => 'qty_per_roll', 'label' => 'Qty/Roll', 'type' => 'Text', 'sort' => 16],
  ['key' => 'roll_direction', 'label' => 'Direction', 'type' => 'Text', 'sort' => 17],
  ['key' => 'remarks', 'label' => 'Remarks', 'type' => 'Text', 'sort' => 18],
];

$allowedTypes = ['Text', 'Number', 'Date', 'Status', 'Priority'];
$statusList = ['Pending', 'Preparing Slitting', 'Slitting Completed', 'Running', 'Completed', 'Hold', 'Hold for Payment', 'Hold for Approval'];
$priorityList = ['Low', 'Normal', 'High', 'Urgent'];

function planning_department_options() {
  return ['label-printing', 'printing', 'slitting', 'packing', 'dispatch', 'general'];
}

function planning_department_label($department) {
  $department = trim((string)$department);
  if ($department === '') return 'General';
  return ucwords(str_replace('-', ' ', $department));
}

function planning_json_response($payload, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function planning_seed_columns(mysqli $db, $department, array $defaultColumns) {
    $chk = $db->prepare("SELECT COUNT(*) AS c FROM planning_board_columns WHERE department = ?");
    $chk->bind_param('s', $department);
    $chk->execute();
    $count = (int)$chk->get_result()->fetch_assoc()['c'];
    if ($count > 0) return;

    $ins = $db->prepare("INSERT INTO planning_board_columns (department, col_key, col_label, col_type, sort_order) VALUES (?,?,?,?,?)");
    foreach ($defaultColumns as $c) {
        $ins->bind_param('ssssi', $department, $c['key'], $c['label'], $c['type'], $c['sort']);
        $ins->execute();
    }
}

function planning_get_columns(mysqli $db, $department, array $defaultColumns) {
    planning_seed_columns($db, $department, $defaultColumns);
    $stmt = $db->prepare("SELECT col_key, col_label, col_type, sort_order FROM planning_board_columns WHERE department = ? ORDER BY sort_order ASC, id ASC");
    $stmt->bind_param('s', $department);
    $stmt->execute();
    $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    if (empty($rows)) {
        return $defaultColumns;
    }

  // One-time migration for legacy board config to Excel-style schema.
  $keys = array_map(function($r){ return (string)$r['col_key']; }, $rows);
  if ($department === 'label-printing' && !in_array('printing_planning', $keys, true)) {
    $del = $db->prepare("DELETE FROM planning_board_columns WHERE department = ?");
    $del->bind_param('s', $department);
    $del->execute();
    planning_seed_columns($db, $department, $defaultColumns);
    return $defaultColumns;
  }

  // Keep main planning board default opening order predictable.
  // Fixed columns render S.N and Job No before configurable board columns.
  if ($department === 'label-printing') {
    $targetFirst = ['sn', 'printing_planning', 'name', 'priority'];
    $currentFirst = array_slice($keys, 0, count($targetFirst));
    $needsReset = false;
    if (in_array('job_no', $keys, true)) {
      $needsReset = true;
    } elseif ($currentFirst !== $targetFirst) {
      $needsReset = true;
    }
    if ($needsReset) {
      $del = $db->prepare("DELETE FROM planning_board_columns WHERE department = ?");
      $del->bind_param('s', $department);
      $del->execute();
      planning_seed_columns($db, $department, $defaultColumns);
      return $defaultColumns;
    }
  }

  // Ensure Priority column exists for every department
  if (!in_array('priority', $keys, true)) {
    $maxSort = 0;
    foreach ($rows as $_r) { $maxSort = max($maxSort, (int)$_r['sort_order']); }
    $priKey = 'priority'; $priLabel = 'Priority'; $priType = 'Priority'; $priSort = $maxSort + 1;
    $pIns = $db->prepare("INSERT IGNORE INTO planning_board_columns (department, col_key, col_label, col_type, sort_order) VALUES (?,?,?,?,?)");
    $pIns->bind_param('ssssi', $department, $priKey, $priLabel, $priType, $priSort);
    $pIns->execute();
    $stmt2 = $db->prepare("SELECT col_key, col_label, col_type, sort_order FROM planning_board_columns WHERE department = ? ORDER BY sort_order ASC, id ASC");
    $stmt2->bind_param('s', $department);
    $stmt2->execute();
    $rows = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);
  }

    $out = [];
    foreach ($rows as $r) {
        $out[] = [
            'key' => $r['col_key'],
            'label' => $r['col_label'],
            'type' => $r['col_type'],
            'sort' => (int)$r['sort_order']
        ];
    }
    return $out;
}

function planning_get_rows(mysqli $db, $department) {
    $stmt = $db->prepare("SELECT p.*, so.order_no, so.client_name
        FROM planning p
        LEFT JOIN sales_orders so ON so.id = p.sales_order_id
        WHERE p.department = ?
          AND LOWER(TRIM(COALESCE(p.status, ''))) <> 'finished'
        ORDER BY
          CASE WHEN p.sequence_order > 0 THEN 0 ELSE 1 END ASC,
          p.sequence_order ASC,
          CASE WHEN p.job_no IS NULL OR p.job_no = '' THEN 1 ELSE 0 END ASC,
          CAST(SUBSTRING_INDEX(p.job_no, '/', -1) AS UNSIGNED) ASC,
          p.id ASC");
    $stmt->bind_param('s', $department);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function planning_normalize_status($status) {
  $s = trim((string)$status);
  if ($s === '') return 'Pending';

  $sLower = strtolower($s);
  if (strpos($sLower, 'printing') !== false && (strpos($sLower, 'done') !== false || strpos($sLower, 'completed') !== false)) {
    return 'Printing Done';
  }
  // Any slitting-stage text should stay in the slitting lane.
  if (strpos($sLower, 'slitting') !== false || strpos($sLower, 'sliting') !== false) {
    if (strpos($sLower, 'completed') !== false || strpos($sLower, 'done') !== false) return 'Slitting Completed';
    return 'Preparing Slitting';
  }

  // Normalize legacy and typo values to the canonical status.
  if (strcasecmp($s, 'Slitting') === 0
      || strcasecmp($s, 'Prepared Slitting') === 0
      || strcasecmp($s, 'Prepared Sliting') === 0
      || strcasecmp($s, 'Preparing Sliting') === 0) {
    return 'Preparing Slitting';
  }

  if (strcasecmp($s, 'Slitting Done') === 0 || strcasecmp($s, 'Sliting Done') === 0 || strcasecmp($s, 'Slitting Completed') === 0) {
    return 'Slitting Completed';
  }

  $allowed = ['Pending', 'Running', 'Completed', 'Printing Done', 'Hold', 'Hold for Payment', 'Hold for Approval', 'Preparing Slitting', 'Slitting', 'Slitting Completed'];
  foreach ($allowed as $v) {
    if (strcasecmp($s, $v) === 0) return $v;
  }
  return 'Pending';
}

function planning_status_badge($status) {
    $s = (string)$status;
    $class = 'pending';
    if (strcasecmp($s, 'Completed') === 0) $class = 'completed';
  elseif (strcasecmp($s, 'Printing Done') === 0) $class = 'completed';
    elseif (strcasecmp($s, 'Running') === 0) $class = 'in-progress';
    elseif (stripos($s, 'Hold') === 0 || strcasecmp($s, 'On Hold') === 0) $class = 'on-hold';
    elseif (strcasecmp($s, 'Slitting') === 0 || strcasecmp($s, 'Preparing Slitting') === 0) $class = 'slitting';
    elseif (strcasecmp($s, 'Slitting Completed') === 0 || strcasecmp($s, 'Sliting Done') === 0 || strcasecmp($s, 'Slitting Done') === 0) $class = 'completed';
    elseif ($s === 'Queued') $class = 'consumed';
    return '<span class="badge badge-' . $class . '">' . e($s) . '</span>';
}

  function planning_status_pill_class($status) {
    $v = strtolower(preg_replace('/[^a-z]/', '', trim((string)$status)));
    if (strpos($v, 'printing') !== false && (strpos($v, 'done') !== false || strpos($v, 'completed') !== false)) return 'printingdone';
    if (strpos($v, 'slitting') !== false || strpos($v, 'sliting') !== false) {
      if (strpos($v, 'completed') !== false || strpos($v, 'done') !== false) return 'completed';
      return 'slitting';
    }
    if ($v === 'running' || $v === 'inprogress') return 'running';
    if ($v === 'completed' || $v === 'slittingcompleted') return 'completed';
    if (strpos($v, 'hold') === 0) return 'hold';
    if ($v === 'preparingslitting' || $v === 'preparingsliting' || $v === 'preparedslitting' || $v === 'preparedsliting' || $v === 'slitting') return 'slitting';
    return 'pending';
  }

  function planning_board_status_badge($status) {
    $s = trim((string)$status);
    if ($s === '') $s = 'Pending';
    $class = 'pending';
    if (strcasecmp($s, 'Running') === 0) $class = 'in-progress';
    elseif (strcasecmp($s, 'Completed') === 0) $class = 'completed';
    elseif (strcasecmp($s, 'Printing Done') === 0) $class = 'completed';
    elseif (strcasecmp($s, 'Preparing Slitting') === 0 || strcasecmp($s, 'Slitting') === 0) $class = 'slitting';
    elseif (strcasecmp($s, 'Slitting Completed') === 0 || strcasecmp($s, 'Sliting Done') === 0 || strcasecmp($s, 'Slitting Done') === 0) $class = 'completed';
    elseif (stripos($s, 'Hold') === 0) $class = 'on-hold';
    return '<span class="badge badge-' . $class . '">' . e($s) . '</span>';
  }

  function planning_try_parse_date($val) {
    $s = trim((string)$val);
    if ($s === '') return '';
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $s)) return $s;
    if (preg_match('/^\d{2}[\.\/-]\d{2}[\.\/-]\d{2,4}$/', $s)) {
      $parts = preg_split('/[\.\/-]/', $s);
      if (count($parts) === 3) {
        $y = strlen($parts[2]) === 2 ? ('20' . $parts[2]) : $parts[2];
        return sprintf('%04d-%02d-%02d', (int)$y, (int)$parts[1], (int)$parts[0]);
      }
    }
    return '';
  }

  function planning_default_dispatch_date($dispatchVal, $orderVal = '', $fallbackScheduled = '') {
    $dispatch = planning_try_parse_date($dispatchVal);
    if ($dispatch !== '') return $dispatch;

    $scheduled = planning_try_parse_date($fallbackScheduled);
    if ($scheduled !== '') return $scheduled;

    $orderDate = planning_try_parse_date($orderVal);
    if ($orderDate === '') return '';

    try {
      $dt = new DateTimeImmutable($orderDate);
      return $dt->modify('+10 days')->format('Y-m-d');
    } catch (Exception $e) {
      return '';
    }
  }

  function planning_extract_row_values(array $row, array $columns, $rowIndex = 0) {
    $extra = json_decode($row['extra_data'] ?? '{}', true);
    if (!is_array($extra)) $extra = [];
    $vals = [];
    foreach ($columns as $c) {
      $k = $c['key'];
      if ($k === 'sn') {
        $vals[$k] = (string)($rowIndex + 1);
        continue;
      }
      if ($k === 'printing_planning') {
        $liveStatus = planning_normalize_status((string)($row['status'] ?? ''));
        $extraStatus = planning_normalize_status((string)($extra['printing_planning'] ?? ''));
        if ($extraStatus === 'Printing Done') {
          $vals[$k] = 'Printing Done';
        } else {
          $vals[$k] = $liveStatus !== 'Pending' ? $liveStatus : ($extraStatus !== 'Pending' ? $extraStatus : 'Pending');
        }
        continue;
      }
      if ($k === 'priority') {
        $vals[$k] = (string)($row['priority'] ?? $extra['priority'] ?? 'Normal');
        continue;
      }
      if ($k === 'dispatch_date') {
        $vals[$k] = planning_default_dispatch_date(
          $extra['dispatch_date'] ?? '',
          $extra['order_date'] ?? ($row['order_date'] ?? ''),
          $row['scheduled_date'] ?? ''
        );
        continue;
      }
      if (array_key_exists($k, $extra)) {
        $val = (string)$extra[$k];
        $vals[$k] = $val;
        continue;
      }
      if ($k === 'name') $vals[$k] = (string)($row['job_name'] ?? '');
      elseif ($k === 'remarks') $vals[$k] = (string)($row['notes'] ?? '');
      else $vals[$k] = (string)($row[$k] ?? '');
    }
    return $vals;
  }

function planning_norm_header_key($key) {
    return strtolower(trim(preg_replace('/\s+/', ' ', (string)$key)));
}

function planning_get_any_key(array $normRow, array $keys) {
    foreach ($keys as $k) {
        $nk = planning_norm_header_key($k);
        if (array_key_exists($nk, $normRow)) return $normRow[$nk];
    }
    return null;
}

function planning_is_safe_image_path($path) {
  $p = str_replace('\\', '/', trim((string)$path));
  if ($p === '') return false;
  return strpos($p, 'uploads/planning/') === 0;
}

function planning_remove_image_file($path) {
  $p = trim((string)$path);
  if ($p === '' || !planning_is_safe_image_path($p)) return;
  $abs = realpath(__DIR__ . '/../../' . ltrim($p, '/'));
  if ($abs && is_file($abs)) {
    @unlink($abs);
    $dir = dirname($abs);
    if (is_dir($dir)) {
      $left = @scandir($dir);
      if (is_array($left) && count($left) <= 2) {
        @rmdir($dir);
      }
    }
  }
}

function planning_save_uploaded_image($file, $rowId, $oldPath = '') {
  if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
    return [false, 'No image selected.', null];
  }
  if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
    return [false, 'Image upload failed.', null];
  }
  if (($file['size'] ?? 0) > 8 * 1024 * 1024) {
    return [false, 'Image size must be below 8MB.', null];
  }

  $tmp = (string)($file['tmp_name'] ?? '');
  $mime = @mime_content_type($tmp);
  $allowed = [
    'image/png' => 'png',
    'image/jpeg' => 'jpg',
    'image/webp' => 'webp',
    'image/gif' => 'gif',
  ];
  if (!isset($allowed[$mime])) {
    return [false, 'Only PNG, JPG, WEBP, GIF files are allowed.', null];
  }

  $ext = $allowed[$mime];
  $dirRel = 'uploads/planning/' . (int)$rowId;
  $dirAbs = __DIR__ . '/../../' . $dirRel;
  if (!is_dir($dirAbs) && !@mkdir($dirAbs, 0777, true)) {
    return [false, 'Unable to prepare upload directory.', null];
  }

  $safeName = 'plan_' . (int)$rowId . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
  $absPath = $dirAbs . '/' . $safeName;
  if (!@move_uploaded_file($tmp, $absPath)) {
    return [false, 'Unable to save uploaded image.', null];
  }

  if ($oldPath !== '' && $oldPath !== ($dirRel . '/' . $safeName)) {
    planning_remove_image_file($oldPath);
  }

  return [true, '', [
    'image_path' => $dirRel . '/' . $safeName,
    'image_name' => (string)($file['name'] ?? $safeName),
    'image_uploaded_at' => date('Y-m-d H:i:s'),
  ]];
}

// AJAX actions for board.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!verifyCSRF($_POST['csrf_token'] ?? '')) {
        planning_json_response(['ok' => false, 'message' => 'Invalid CSRF token.'], 400);
    }

    $action = (string)$_POST['action'];

    // Permission guards for AJAX actions
    $ajaxCanAdd    = currentPageAction('add');
    $ajaxCanEdit   = currentPageAction('edit');
    $ajaxCanDelete = currentPageAction('delete');

    if (in_array($action, ['create_row', 'import_rows'], true) && !$ajaxCanAdd) {
        planning_json_response(['ok' => false, 'message' => 'Permission denied. You do not have Add access.'], 403);
    }
    if (in_array($action, ['save_row', 'reorder_rows', 'update_priority', 'upload_job_image', 'save_columns'], true) && !$ajaxCanEdit) {
        planning_json_response(['ok' => false, 'message' => 'Permission denied. You do not have Edit access.'], 403);
    }
    if (in_array($action, ['delete_row', 'delete_job_image'], true) && !$ajaxCanDelete) {
        planning_json_response(['ok' => false, 'message' => 'Permission denied. You do not have Delete access.'], 403);
    }

    if ($action === 'save_row') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) planning_json_response(['ok' => false, 'message' => 'Invalid row id.'], 400);

      $rowValues = json_decode((string)($_POST['row_values_json'] ?? '{}'), true);
      if (!is_array($rowValues)) $rowValues = [];
      if (empty($rowValues)) {
        foreach ($_POST as $k => $v) {
          if (in_array($k, ['action', 'id', 'csrf_token'], true)) continue;
          $rowValues[$k] = is_scalar($v) ? (string)$v : '';
        }
      }

      $jobName = trim((string)($rowValues['name'] ?? $rowValues['job_name'] ?? ''));
        if ($jobName === '') planning_json_response(['ok' => false, 'message' => 'Job name is required.'], 400);

      $statusRaw = trim((string)($rowValues['printing_planning'] ?? $rowValues['status'] ?? 'Pending'));
      if ($statusRaw === '') $statusRaw = 'Pending';
      $status = planning_normalize_status($statusRaw);
      // Persist canonical status token in extra_data so reload keeps correct color class.
      $rowValues['printing_planning'] = $status;
      $priority = (string)($rowValues['priority'] ?? 'Normal');
        if (!in_array($priority, $priorityList, true)) $priority = 'Normal';

      $rowValues['order_date'] = planning_try_parse_date($rowValues['order_date'] ?? '');
      $rowValues['dispatch_date'] = planning_default_dispatch_date(
        $rowValues['dispatch_date'] ?? '',
        $rowValues['order_date'] ?? '',
        $rowValues['scheduled_date'] ?? ''
      );

      $machine = trim((string)($rowValues['machine'] ?? ''));
      $operator = trim((string)($rowValues['operator_name'] ?? ''));
      $notes = trim((string)($rowValues['remarks'] ?? $rowValues['notes'] ?? ''));
      $scheduled = $rowValues['dispatch_date'];

      // Preserve uploaded image metadata stored in extra_data when saving row fields.
      $selExtra = $db->prepare("SELECT job_no, job_name, extra_data FROM planning WHERE id = ? AND department = ? LIMIT 1");
      $selExtra->bind_param('is', $id, $department);
      $selExtra->execute();
      $existingRow = $selExtra->get_result()->fetch_assoc();
      $existingExtra = json_decode((string)($existingRow['extra_data'] ?? '{}'), true);
      if (!is_array($existingExtra)) $existingExtra = [];
      foreach (['image_path', 'image_name', 'image_uploaded_at'] as $imgKey) {
        if (!array_key_exists($imgKey, $rowValues) && array_key_exists($imgKey, $existingExtra)) {
          $rowValues[$imgKey] = $existingExtra[$imgKey];
        }
      }

      $extraJson = json_encode($rowValues, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
      $up = $db->prepare("UPDATE planning SET job_name=?, machine=?, operator_name=?, scheduled_date=NULLIF(?, ''), status=?, priority=?, notes=?, extra_data=? WHERE id=? AND department=?");
      $up->bind_param('ssssssssis', $jobName, $machine, $operator, $scheduled, $status, $priority, $notes, $extraJson, $id, $department);
        $ok = $up->execute();
        if ($ok) {
          planningCreateNotifications(
            $db,
            (string)($existingRow['job_no'] ?? ''),
            $jobName !== '' ? $jobName : (string)($existingRow['job_name'] ?? ''),
            $department,
            'updated'
          );
        }
        planning_json_response(['ok' => (bool)$ok, 'message' => $ok ? 'Row updated.' : 'Update failed.']);
    }

    if ($action === 'delete_row') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) planning_json_response(['ok' => false, 'message' => 'Invalid row id.'], 400);

      $sel = $db->prepare("SELECT job_no, job_name, extra_data FROM planning WHERE id = ? AND department = ? LIMIT 1");
      $sel->bind_param('is', $id, $department);
      $sel->execute();
      $row = $sel->get_result()->fetch_assoc();
      if ($row) {
        $extra = json_decode((string)($row['extra_data'] ?? '{}'), true);
        if (is_array($extra) && !empty($extra['image_path'])) {
          planning_remove_image_file((string)$extra['image_path']);
        }
      }

        $del = $db->prepare("DELETE FROM planning WHERE id = ? AND department = ?");
        $del->bind_param('is', $id, $department);
        $ok = $del->execute();
        if ($ok && $row) {
          planningCreateNotifications($db, (string)($row['job_no'] ?? ''), (string)($row['job_name'] ?? ''), $department, 'deleted');
        }
        planning_json_response(['ok' => (bool)$ok, 'message' => $ok ? 'Row deleted.' : 'Delete failed.']);
    }

    if ($action === 'upload_job_image') {
      $id = (int)($_POST['id'] ?? 0);
      if ($id <= 0) planning_json_response(['ok' => false, 'message' => 'Invalid row id.'], 400);
      if (empty($_FILES['job_image'])) {
        planning_json_response(['ok' => false, 'message' => 'No image selected.'], 400);
      }

      $sel = $db->prepare("SELECT extra_data FROM planning WHERE id = ? AND department = ? LIMIT 1");
      $sel->bind_param('is', $id, $department);
      $sel->execute();
      $row = $sel->get_result()->fetch_assoc();
      if (!$row) {
        planning_json_response(['ok' => false, 'message' => 'Planning row not found.'], 404);
      }

      $extra = json_decode((string)($row['extra_data'] ?? '{}'), true);
      if (!is_array($extra)) $extra = [];
      $oldPath = trim((string)($extra['image_path'] ?? ''));

      list($saved, $err, $meta) = planning_save_uploaded_image($_FILES['job_image'], $id, $oldPath);
      if (!$saved || !is_array($meta)) {
        planning_json_response(['ok' => false, 'message' => $err !== '' ? $err : 'Image upload failed.'], 400);
      }

      $extra['image_path'] = $meta['image_path'];
      $extra['image_name'] = $meta['image_name'];
      $extra['image_uploaded_at'] = $meta['image_uploaded_at'];

      $extraJson = json_encode($extra, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
      $up = $db->prepare("UPDATE planning SET extra_data = ? WHERE id = ? AND department = ?");
      $up->bind_param('sis', $extraJson, $id, $department);
      $ok = $up->execute();
      if (!$ok) {
        planning_remove_image_file((string)$meta['image_path']);
        planning_json_response(['ok' => false, 'message' => 'Image saved but database update failed.'], 500);
      }

      planning_json_response([
        'ok' => true,
        'message' => 'Image uploaded.',
        'image_path' => $meta['image_path'],
        'image_name' => $meta['image_name'],
        'image_uploaded_at' => $meta['image_uploaded_at'],
        'image_url' => appUrl($meta['image_path'])
      ]);
    }

    if ($action === 'delete_job_image') {
      $id = (int)($_POST['id'] ?? 0);
      if ($id <= 0) planning_json_response(['ok' => false, 'message' => 'Invalid row id.'], 400);

      $sel = $db->prepare("SELECT extra_data FROM planning WHERE id = ? AND department = ? LIMIT 1");
      $sel->bind_param('is', $id, $department);
      $sel->execute();
      $row = $sel->get_result()->fetch_assoc();
      if (!$row) {
        planning_json_response(['ok' => false, 'message' => 'Planning row not found.'], 404);
      }

      $extra = json_decode((string)($row['extra_data'] ?? '{}'), true);
      if (!is_array($extra)) $extra = [];
      $oldPath = trim((string)($extra['image_path'] ?? ''));
      if ($oldPath !== '') {
        planning_remove_image_file($oldPath);
      }

      unset($extra['image_path'], $extra['image_name'], $extra['image_uploaded_at']);
      $extraJson = json_encode($extra, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
      $up = $db->prepare("UPDATE planning SET extra_data = ? WHERE id = ? AND department = ?");
      $up->bind_param('sis', $extraJson, $id, $department);
      $ok = $up->execute();
      planning_json_response(['ok' => (bool)$ok, 'message' => $ok ? 'Image removed.' : 'Unable to remove image.']);
    }

    if ($action === 'create_row') {
      $rowValues = json_decode((string)($_POST['row_values_json'] ?? '{}'), true);
      if (!is_array($rowValues)) $rowValues = [];

      $jobName = trim((string)($rowValues['name'] ?? $_POST['job_name'] ?? ''));
        if ($jobName === '') planning_json_response(['ok' => false, 'message' => 'Job name is required.'], 400);

      $statusRaw = 'Pending';
      $rowValues['printing_planning'] = 'Pending';

      $status = 'Pending';
      $priority = (string)($rowValues['priority'] ?? $_POST['priority'] ?? 'Normal');
        if (!in_array($priority, $priorityList, true)) $priority = 'Normal';

      $rowValues['order_date'] = planning_try_parse_date($rowValues['order_date'] ?? $_POST['order_date'] ?? '');
      $rowValues['dispatch_date'] = planning_default_dispatch_date(
        $rowValues['dispatch_date'] ?? '',
        $rowValues['order_date'] ?? '',
        $_POST['scheduled_date'] ?? ''
      );

      $machine = trim((string)($rowValues['machine'] ?? $_POST['machine'] ?? ''));
      $operator = trim((string)($rowValues['operator_name'] ?? $_POST['operator_name'] ?? ''));
      $notes = trim((string)($rowValues['remarks'] ?? $_POST['notes'] ?? ''));
      $scheduled = $rowValues['dispatch_date'];

      $extraJson = json_encode($rowValues, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

      // Auto-generate planning job number
      $planJobNo = getNextId('planning');
      if (!$planJobNo) $planJobNo = 'PLN-' . date('Ymd') . '-' . rand(1000,9999);

      $ins = $db->prepare("INSERT INTO planning (job_no, sales_order_id, job_name, machine, operator_name, scheduled_date, status, priority, notes, department, extra_data, created_by) VALUES (?,NULL,?,?,?,NULLIF(?, ''),?,?,?,?,?,?)");
        $uid = (int)($_SESSION['user_id'] ?? 0);
      $ins->bind_param('ssssssssssi', $planJobNo, $jobName, $machine, $operator, $scheduled, $status, $priority, $notes, $department, $extraJson, $uid);
        $ok = $ins->execute();
        if ($ok) planningCreateNotifications($db, $planJobNo, $jobName, $department, 'added');
        planning_json_response(['ok' => (bool)$ok, 'id' => $ok ? $db->insert_id : 0, 'job_no' => $planJobNo, 'message' => $ok ? 'Row created.' : 'Create failed.']);
    }

    if ($action === 'save_columns') {
        $payload = $_POST['columns_json'] ?? '[]';
        $cols = json_decode((string)$payload, true);
        if (!is_array($cols)) planning_json_response(['ok' => false, 'message' => 'Invalid payload.'], 400);

        $db->begin_transaction();
        try {
            $del = $db->prepare("DELETE FROM planning_board_columns WHERE department = ?");
            $del->bind_param('s', $department);
            $del->execute();

            $ins = $db->prepare("INSERT INTO planning_board_columns (department, col_key, col_label, col_type, sort_order) VALUES (?,?,?,?,?)");
            $sort = 1;
            foreach ($cols as $c) {
                $key = trim((string)($c['key'] ?? ''));
                $label = trim((string)($c['label'] ?? ''));
                $type = trim((string)($c['type'] ?? 'Text'));
                if ($key === '' || $label === '') continue;
                if (!in_array($type, $allowedTypes, true)) $type = 'Text';
                $ins->bind_param('ssssi', $department, $key, $label, $type, $sort);
                $ins->execute();
                $sort++;
            }
            $db->commit();
            planning_json_response(['ok' => true, 'message' => 'Board headers updated.']);
        } catch (Exception $e) {
            $db->rollback();
            planning_json_response(['ok' => false, 'message' => 'Unable to save headers.'], 500);
        }
    }

    if ($action === 'import_rows') {
        $payload = $_POST['rows_json'] ?? '[]';
        $rows = json_decode((string)$payload, true);
        if (!is_array($rows)) planning_json_response(['ok' => false, 'message' => 'Invalid rows payload.'], 400);

      $activeColumns = planning_get_columns($db, $department, $defaultColumns);

        $ins = $db->prepare("INSERT INTO planning (job_no, sales_order_id, job_name, machine, operator_name, scheduled_date, status, priority, notes, department, extra_data, created_by) VALUES (?,NULL,?,?,?,NULLIF(?, ''),?,?,?,?,?,?)");
        $uid = (int)($_SESSION['user_id'] ?? 0);
        $count = 0;

        foreach ($rows as $r) {
            if (!is_array($r)) continue;

            $normRow = [];
            foreach ($r as $rk => $rv) {
                $normRow[planning_norm_header_key($rk)] = is_scalar($rv) ? trim((string)$rv) : '';
            }

            $rowValues = [];
            foreach ($activeColumns as $col) {
                $k = $col['key'];
                if ($k === 'sn') continue;
                $rowValues[$k] = '';
            }

            $aliases = [
                'order_date' => ['order_date', 'order date'],
                'dispatch_date' => ['dispatch_date', 'dispatch date'],
                'printing_planning' => ['printing_planning', 'printing planing', 'status', 'planing', 'planning'],
                'plate_no' => ['plate_no', 'plate no', 'plate no.'],
                'name' => ['name', 'job name', 'job_name'],
                'size' => ['size'],
                'repeat' => ['repeat'],
                'material' => ['material'],
                'paper_size' => ['paper_size', 'paper size'],
                'die' => ['die'],
                'allocate_mtrs' => ['allocate_mtrs', 'mtrs', 'allocate mtrs', 'allocate'],
                'qty_pcs' => ['qty_pcs', 'qty', 'qty. (pcs)', 'qty (pcs)'],
                'core_size' => ['core_size', 'core', 'core size'],
                'qty_per_roll' => ['qty_per_roll', 'qty/roll', 'qty per roll', 'qty. per roll'],
                'roll_direction' => ['roll_direction', 'direction', 'roll direction'],
                'remarks' => ['remarks', 'notes']
            ];

            foreach ($aliases as $k => $tryKeys) {
                $v = planning_get_any_key($normRow, $tryKeys);
               if ($v !== null && trim((string)$v) !== '') {
                 $rowValues[$k] = (string)$v;
               } else {
                 // Show NA for missing/blank values - user can edit them later
                 $rowValues[$k] = 'NA';
               }
            }

            $jobName = trim((string)($rowValues['name'] ?? ''));
            if ($jobName === '') continue;

            $machine = (string)(planning_get_any_key($normRow, ['machine']) ?? '');
            $operator = (string)(planning_get_any_key($normRow, ['operator_name', 'operator']) ?? '');
            $rowValues['order_date'] = planning_try_parse_date($rowValues['order_date'] ?? '');
            $scheduled = planning_default_dispatch_date(
              $rowValues['dispatch_date'] ?? '',
              $rowValues['order_date'] ?? '',
              planning_get_any_key($normRow, ['scheduled_date', 'scheduled date']) ?? ''
            );
            $rowValues['dispatch_date'] = $scheduled;

            $status = 'Pending';
            $rowValues['printing_planning'] = 'Pending';

            $priority = (string)(planning_get_any_key($normRow, ['priority']) ?? 'Normal');
            if (!in_array($priority, $priorityList, true)) $priority = 'Normal';

            $notes = trim((string)($rowValues['remarks'] ?? ''));
            $extraJson = json_encode($rowValues, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            // Auto-generate planning job number for each imported row
            $planJobNo = getNextId('planning');
            if (!$planJobNo) $planJobNo = 'PLN-' . date('Ymd') . '-' . rand(1000,9999);

            $ins->bind_param('ssssssssssi', $planJobNo, $jobName, $machine, $operator, $scheduled, $status, $priority, $notes, $department, $extraJson, $uid);
            if ($ins->execute()) {
              planningCreateNotifications($db, $planJobNo, $jobName, $department, 'imported');
              $count++;
            }
        }

        if ($count === 0) {
            planning_json_response(['ok' => false, 'message' => 'Import failed: No valid rows matched required Job Name column.'], 400);
        }
        planning_json_response(['ok' => true, 'message' => 'Import completed.', 'count' => $count]);
    }

    if ($action === 'reorder_rows') {
        $order = json_decode((string)($_POST['order_json'] ?? '[]'), true);
        if (!is_array($order) || empty($order)) planning_json_response(['ok' => false, 'message' => 'Invalid order data.'], 400);
        $up = $db->prepare("UPDATE planning SET sequence_order = ? WHERE id = ? AND department = ?");
        foreach ($order as $idx => $rowId) {
            $seq = (int)($idx + 1);
            $rid = (int)$rowId;
            if ($rid <= 0) continue;
            $up->bind_param('iis', $seq, $rid, $department);
            $up->execute();
        }
        planningCreateNotifications($db, '', 'Planning board', $department, 'sequence updated');
        planning_json_response(['ok' => true, 'message' => 'Sequence updated.']);
    }

    if ($action === 'update_priority') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) planning_json_response(['ok' => false, 'message' => 'Invalid row id.'], 400);
        $newPriority = (string)($_POST['priority'] ?? 'Normal');
        if (!in_array($newPriority, $priorityList, true)) $newPriority = 'Normal';
        $sel = $db->prepare("SELECT job_no, job_name, extra_data FROM planning WHERE id = ? AND department = ? LIMIT 1");
        $sel->bind_param('is', $id, $department);
        $sel->execute();
        $existRow = $sel->get_result()->fetch_assoc();
        if ($existRow) {
            $ex = json_decode((string)($existRow['extra_data'] ?? '{}'), true);
            if (!is_array($ex)) $ex = [];
            $ex['priority'] = $newPriority;
            $exJson = json_encode($ex, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $up = $db->prepare("UPDATE planning SET priority = ?, extra_data = ? WHERE id = ? AND department = ?");
            $up->bind_param('ssis', $newPriority, $exJson, $id, $department);
            $ok = $up->execute();
            if ($ok) {
              planningCreateNotifications($db, (string)($existRow['job_no'] ?? ''), (string)($existRow['job_name'] ?? ''), $department, 'priority updated');
            }
        } else {
            $ok = false;
        }
        planning_json_response(['ok' => (bool)$ok, 'message' => $ok ? 'Priority updated.' : 'Update failed.']);
    }

    planning_json_response(['ok' => false, 'message' => 'Unknown action.'], 400);
}

$columns = planning_get_columns($db, $department, $defaultColumns);
$rows = planning_get_rows($db, $department);
$planningJobPreview = previewNextId('planning') ?: 'Auto-generated on save';
$deptOptions = planning_department_options();
$boardUrl = appUrl('modules/planning/index.php?department=' . rawurlencode($department));
$historyUrl = appUrl('modules/planning/history.php?department=' . rawurlencode($department));

// Granular permissions: admin always gets full access
$canAdd    = currentPageAction('add');
$canEdit   = currentPageAction('edit');
$canDelete = currentPageAction('delete');

$pageTitle = 'Planning Board';
include __DIR__ . '/../../includes/header.php';
?>

<div class="breadcrumb">
  <a href="<?= BASE_URL ?>/modules/dashboard/index.php">Dashboard</a><span class="breadcrumb-sep">›</span>
  <span>Planning</span>
</div>

<div class="planning-view-switch">
  <a href="<?= e($boardUrl) ?>" class="planning-view-link is-active"><i class="bi bi-grid-1x2"></i> Board</a>
  <a href="<?= e($historyUrl) ?>" class="planning-view-link"><i class="bi bi-clock-history"></i> History</a>
</div>

<div class="page-header">
  <div>
    <h1>Planning Board</h1>
    <p>Live planning board with inline editing, Excel import, and configurable headers.</p>
  </div>
  <div class="d-flex gap-8">
    <button type="button" class="btn btn-ghost" id="btn-print-pdf"><i class="bi bi-printer"></i> Print / PDF</button>
    <button type="button" class="btn btn-ghost" id="btn-export-excel"><i class="bi bi-file-earmark-excel"></i> Export Excel</button>
    <?php if ($canEdit): ?>
    <button type="button" class="btn btn-ghost" id="btn-board-config"><i class="bi bi-layout-text-window-reverse"></i> Board Layout</button>
    <?php endif; ?>
    <?php if ($canAdd): ?>
    <button type="button" class="btn btn-secondary" id="btn-import"><i class="bi bi-file-earmark-arrow-up"></i> Import Excel</button>
    <button type="button" class="btn btn-primary" id="btn-add-row"><i class="bi bi-plus-circle"></i> Add Job Entry</button>
    <?php endif; ?>
    <input type="file" id="excel-file" accept=".xlsx,.xls" style="display:none">
  </div>
</div>

<div class="card mt-16">
  <div class="card-header">
    <span class="card-title">Department: <?= e($department) ?>
      <span class="badge badge-consumed" style="margin-left:6px"><?= count($rows) ?></span>
    </span>
    <div class="d-flex gap-8">
      <select id="dept-switch" class="form-control" style="min-width:210px">
        <?php foreach ($deptOptions as $d): ?>
          <option value="<?= e($d) ?>" <?= $d === $department ? 'selected' : '' ?>><?= e(planning_department_label($d)) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>

  <div class="table-wrap planning-board-wrap">
    <table id="planning-board-table" class="planning-board-table">
      <thead>
        <tr>
          <th class="seq-drag-col">&nbsp;</th>
          <th class="sticky-col">Actions</th>
          <th>S.N</th>
          <th>Job No</th>
          <?php foreach ($columns as $c): ?>
            <?php if ($c['key'] === 'sn') continue; ?>
            <th draggable="true" data-col-key="<?= e($c['key']) ?>"><?= e($c['label']) ?></th>
          <?php endforeach; ?>
          <th>Job Image</th>
        </tr>
      </thead>
      <tbody>
      <?php $visibleColCount = 0; foreach ($columns as $_c) { if ($_c['key'] !== 'sn') $visibleColCount++; } ?>
      <?php if (empty($rows)): ?>
        <tr><td colspan="<?= $visibleColCount + 5 ?>" class="table-empty"><i class="bi bi-inbox"></i>No planning jobs found.</td></tr>
      <?php else: ?>
        <?php foreach ($rows as $idx => $r): ?>
          <?php
            $rowVals = planning_extract_row_values($r, $columns, $idx);
            $rowStatusVal = 'Pending';
            foreach ($columns as $_sc) { if ($_sc['type'] === 'Status') { $rowStatusVal = (string)($rowVals[$_sc['key']] ?? 'Pending'); break; } }
            $rowSCls = planning_status_pill_class($rowStatusVal);
            $rowExtra = json_decode((string)($r['extra_data'] ?? '{}'), true);
            if (!is_array($rowExtra)) $rowExtra = [];
            $jobImagePath = trim((string)($rowExtra['image_path'] ?? ''));
            $jobImageName = trim((string)($rowExtra['image_name'] ?? ''));
            $jobImageUploadedAt = trim((string)($rowExtra['image_uploaded_at'] ?? ''));
            $jobImageUrl = $jobImagePath !== '' ? appUrl($jobImagePath) : '';
          ?>
          <tr data-id="<?= (int)$r['id'] ?>" class="row-s-<?= $rowSCls ?>" <?= $canEdit ? 'draggable="true"' : '' ?>>
            <td class="seq-drag-col <?= $canEdit ? 'seq-drag-handle' : '' ?>" <?= $canEdit ? 'title="Drag to reorder"' : '' ?>><?php if ($canEdit): ?><i class="bi bi-grip-vertical"></i><?php endif; ?></td>
            <td class="sticky-col">
              <div class="row-actions">
                <?php if ($canEdit): ?>
                <button class="btn btn-secondary btn-sm btn-edit" type="button" title="Edit"><i class="bi bi-pencil"></i></button>
                <button class="btn btn-primary btn-sm btn-save" type="button" title="Save" style="display:none"><i class="bi bi-check2-circle"></i></button>
                <button class="btn btn-ghost btn-sm btn-cancel" type="button" title="Cancel" style="display:none"><i class="bi bi-x-circle"></i></button>
                <?php endif; ?>
                <?php if ($canDelete): ?>
                <button class="btn btn-danger btn-sm btn-delete" type="button" title="Delete"><i class="bi bi-trash"></i></button>
                <?php endif; ?>
              </div>
            </td>
            <td><?= (int)($idx + 1) ?></td>
            <td class="job-no-cell">
              <strong><?= e($r['job_no'] ?? '—') ?></strong>
              <?php
                $linkedJobs = $planLinkedJobs[(int)$r['id']] ?? [];
                foreach ($linkedJobs as $lj):
                  $ljNo = e($lj['job_no'] ?? '');
                  $ljDept = strtolower(trim((string)($lj['department'] ?? '')));
                  $ljType = strtolower(trim((string)($lj['job_type'] ?? '')));
                  $ljUrl = '';
                  if ($ljDept === 'jumbo_slitting' || $ljType === 'slitting') {
                    $ljUrl = BASE_URL . '/modules/jobs/jumbo/index.php';
                  } elseif ($ljDept === 'flexo_printing' || $ljType === 'printing') {
                    $ljUrl = BASE_URL . '/modules/jobs/printing/index.php';
                  }
                  if ($ljUrl !== '' && $ljNo !== ''):
              ?>
                <a href="<?= e($ljUrl) ?>" class="linked-job-link" title="Open <?= $ljNo ?> job card"><?= $ljNo ?></a>
              <?php endif; endforeach; ?>
            </td>
            <?php foreach ($columns as $c): ?>
              <?php if ($c['key'] === 'sn') continue; ?>
              <?php
                $k = $c['key'];
                $v = (string)($rowVals[$k] ?? '');
              ?>
              <td data-key="<?= e($k) ?>" data-type="<?= e($c['type']) ?>">
                <?php if ($c['type'] === 'Status'): ?>
                  <span class="cell-display status-pill status-pill-<?= e(planning_status_pill_class($v ?: 'Pending')) ?>"><?= e($v ?: 'Pending') ?></span>
                  <?php
                    $statusOptions = array_values(array_unique(array_merge(
                      ['Pending', 'Preparing Slitting', 'Slitting Completed', 'Running', 'Completed', 'Hold', 'Hold for Payment', 'Hold for Approval'],
                      $statusList,
                      [$v ?: 'Pending']
                    )));
                  ?>
                  <select class="cell-input cell-select-status form-control" style="display:none">
                    <?php foreach ($statusOptions as $s): ?><option value="<?= e($s) ?>"<?= $v === $s ? ' selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?>
                  </select>
                <?php elseif ($c['type'] === 'Priority'): ?>
                  <?php $pVal = $v ?: 'Normal'; $pCls = strtolower($pVal); ?>
                  <span class="cell-display priority-pill priority-pill-<?= e($pCls) ?>"><?= e($pVal) ?></span>
                  <select class="cell-input cell-select-priority form-control" style="display:none">
                    <?php foreach ($priorityList as $p): ?><option value="<?= e($p) ?>"<?= $pVal === $p ? ' selected' : '' ?>><?= e($p) ?></option><?php endforeach; ?>
                  </select>
                <?php else: ?>
                  <span class="cell-display"><?= e($v !== '' ? $v : '—') ?></span>
                  <input class="cell-input form-control" type="text" value="<?= e($v) ?>" style="display:none">
                <?php endif; ?>
              </td>
            <?php endforeach; ?>
            <td class="job-image-cell"
                data-image-path="<?= e($jobImagePath) ?>"
                data-image-url="<?= e($jobImageUrl) ?>"
                data-image-name="<?= e($jobImageName) ?>"
                data-image-uploaded-at="<?= e($jobImageUploadedAt) ?>">
              <div class="job-image-box <?= $jobImageUrl !== '' ? 'has-image' : 'no-image' ?>">
                <?php if ($jobImageUrl !== ''): ?>
                  <button type="button" class="job-image-thumb-btn" title="Open image">
                    <img src="<?= e($jobImageUrl) ?>" alt="Job image" class="job-image-thumb">
                  </button>
                <?php else: ?>
                  <button type="button" class="job-image-empty-btn" title="Add image"><i class="bi bi-image"></i></button>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="planning-modal" id="modal-add" style="display:none">
  <div class="planning-modal-card">
    <div class="planning-modal-head">
      <h3>Add Job Entry</h3>
      <button type="button" class="btn btn-ghost btn-sm modal-close"><i class="bi bi-x-lg"></i></button>
    </div>
    <form id="form-add-row">
      <div class="planning-job-preview-box">
        <span class="planning-job-preview-label">Job ID</span>
        <strong id="planning-job-preview"><?= e($planningJobPreview) ?></strong>
        <small>Final number is assigned when you save.</small>
      </div>
      <div class="planning-grid">
        <?php foreach ($columns as $c): ?>
          <?php if ($c['key'] === 'sn') continue; ?>
          <div<?= $c['key'] === 'remarks' ? ' style="grid-column:1 / -1"' : '' ?>>
            <label><?= e($c['label']) ?><?= $c['key'] === 'name' ? ' *' : '' ?></label>
            <?php if ($c['type'] === 'Status'): ?>
              <input class="form-control" type="text" value="Pending" readonly>
              <input type="hidden" name="<?= e($c['key']) ?>" value="Pending">
            <?php elseif ($c['type'] === 'Priority'): ?>
              <select class="form-control" name="<?= e($c['key']) ?>">
                <?php foreach ($priorityList as $p): ?><option value="<?= e($p) ?>"<?= $p === 'Normal' ? ' selected' : '' ?>><?= e($p) ?></option><?php endforeach; ?>
              </select>
            <?php else: ?>
              <input class="form-control" name="<?= e($c['key']) ?>" type="<?= $c['type'] === 'Number' ? 'number' : ($c['type'] === 'Date' ? 'date' : 'text') ?>" <?= $c['key'] === 'name' ? 'required' : '' ?>>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
        <div style="grid-column:1 / -1">
          <label>Job Image (Optional)</label>
          <input class="form-control" name="job_image" type="file" accept="image/png,image/jpeg,image/webp,image/gif">
        </div>
      </div>
      <div class="planning-modal-foot">
        <button type="submit" class="btn btn-primary"><i class="bi bi-check2-circle"></i> Save Entry</button>
      </div>
    </form>
  </div>
</div>

<div class="planning-modal" id="modal-config" style="display:none">
  <div class="planning-modal-card">
    <div class="planning-modal-head">
      <h3>Board Header Configuration</h3>
      <button type="button" class="btn btn-ghost btn-sm modal-close"><i class="bi bi-x-lg"></i></button>
    </div>
    <div id="config-list" class="config-list"></div>
    <div class="planning-modal-foot">
      <button type="button" class="btn btn-primary" id="btn-save-config"><i class="bi bi-save"></i> Save Header Changes</button>
    </div>
  </div>
</div>

<div class="planning-modal" id="modal-import-map" style="display:none">
  <div class="planning-modal-card">
    <div class="planning-modal-head">
      <h3>Excel Column Mapping</h3>
      <button type="button" class="btn btn-ghost btn-sm modal-close"><i class="bi bi-x-lg"></i></button>
    </div>
    <div style="padding:10px 16px 0;color:#475569;font-size:.82rem">
      Map uploaded Excel columns to Planning fields before import.
    </div>
    <div id="import-map-list" class="import-map-list"></div>
    <div class="planning-modal-foot">
      <button type="button" class="btn btn-ghost" id="btn-import-map-cancel">Cancel</button>
      <button type="button" class="btn btn-primary" id="btn-import-map-apply"><i class="bi bi-check2-circle"></i> Import Mapped Rows</button>
    </div>
  </div>
</div>

<div class="planning-modal" id="modal-plan-detail" style="display:none">
  <div class="planning-modal-card">
    <div class="planning-modal-head">
      <h3>Plan Details</h3>
      <button type="button" class="btn btn-ghost btn-sm modal-close"><i class="bi bi-x-lg"></i></button>
    </div>
    <div id="plan-detail-content" class="plan-detail-grid"></div>
  </div>
</div>

<div class="planning-modal" id="modal-image-viewer" style="display:none">
  <div class="planning-modal-card image-viewer-modal-card">
    <div class="planning-modal-head">
      <h3>Planning Job Image</h3>
      <button type="button" class="btn btn-ghost btn-sm modal-close"><i class="bi bi-x-lg"></i></button>
    </div>
    <div class="image-viewer-toolbar">
      <div class="image-viewer-meta" id="image-viewer-meta"></div>
      <div class="image-viewer-controls">
        <button type="button" class="btn btn-ghost btn-sm" id="image-zoom-out"><i class="bi bi-dash-lg"></i></button>
        <button type="button" class="btn btn-ghost btn-sm" id="image-zoom-reset">100%</button>
        <button type="button" class="btn btn-ghost btn-sm" id="image-zoom-in"><i class="bi bi-plus-lg"></i></button>
        <button type="button" class="btn btn-ghost btn-sm" id="image-upload-btn"><i class="bi bi-upload"></i> Upload</button>
        <button type="button" class="btn btn-secondary btn-sm" id="image-edit-btn"><i class="bi bi-pencil-square"></i> Edit</button>
        <button type="button" class="btn btn-danger btn-sm" id="image-delete-btn"><i class="bi bi-trash"></i> Delete</button>
      </div>
    </div>
    <div class="image-viewer-stage" id="image-viewer-stage">
      <img id="image-viewer-img" alt="Planning job image">
    </div>
  </div>
</div>

<form id="csrf-form" style="display:none">
  <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
  <input type="hidden" name="department" value="<?= e($department) ?>">
</form>

<script src="https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.bundle.js"></script>
<script>
(function(){
  'use strict';

  var boardTable = document.getElementById('planning-board-table');
  var deptSwitch = document.getElementById('dept-switch');
  var addModal = document.getElementById('modal-add');
  var cfgModal = document.getElementById('modal-config');
  var importMapModal = document.getElementById('modal-import-map');
  var detailModal = document.getElementById('modal-plan-detail');
  var imageViewerModal = document.getElementById('modal-image-viewer');
  var imageViewerImg = document.getElementById('image-viewer-img');
  var imageViewerMeta = document.getElementById('image-viewer-meta');
  var imageZoomInBtn = document.getElementById('image-zoom-in');
  var imageZoomOutBtn = document.getElementById('image-zoom-out');
  var imageZoomResetBtn = document.getElementById('image-zoom-reset');
  var imageUploadBtn = document.getElementById('image-upload-btn');
  var imageEditBtn = document.getElementById('image-edit-btn');
  var imageDeleteBtn = document.getElementById('image-delete-btn');
  var imageViewerStage = document.getElementById('image-viewer-stage');
  var fileInput = document.getElementById('excel-file');
  var btnExportExcel = document.getElementById('btn-export-excel');
  var btnPrintPdf = document.getElementById('btn-print-pdf');
  var importMapList = document.getElementById('import-map-list');
  var btnImportMapApply = document.getElementById('btn-import-map-apply');
  var btnImportMapCancel = document.getElementById('btn-import-map-cancel');
  var columns = <?= json_encode($columns, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
  var csrfToken = document.querySelector('#csrf-form [name="csrf_token"]').value;
  var currentDepartment = <?= json_encode($department, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
  var CAN_ADD = <?= $canAdd ? 'true' : 'false' ?>;
  var CAN_EDIT = <?= $canEdit ? 'true' : 'false' ?>;
  var CAN_DELETE = <?= $canDelete ? 'true' : 'false' ?>;
  var imageViewerScale = 1;
  var imageViewerRowId = '';
  var pendingImportRows = [];
  var pendingImportHeaders = [];
  var imageUploadInput = document.createElement('input');
  imageUploadInput.type = 'file';
  imageUploadInput.accept = 'image/png,image/jpeg,image/webp,image/gif';
  imageUploadInput.style.display = 'none';
  document.body.appendChild(imageUploadInput);

  function safeText(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function boardHeaders() {
    var headers = ['S.N', 'Job No'];
    columns.forEach(function(col){
      if (col.key === 'sn') return;
      headers.push(col.label || col.key || '');
    });
    return headers;
  }

  function boardRows() {
    return Array.prototype.slice.call(boardTable.querySelectorAll('tbody tr[data-id]')).map(function(tr){
      var row = [];
      var snCell = tr.children[2];
      row.push(snCell ? snCell.textContent.trim() : '');
      var jobNoCell = tr.querySelector('.job-no-cell');
      row.push(jobNoCell ? jobNoCell.textContent.trim() : '');
      Array.prototype.slice.call(tr.querySelectorAll('td[data-key]')).forEach(function(td){
        var raw = td.getAttribute('data-raw');
        var text = raw !== null ? raw : (td.querySelector('.cell-display') ? td.querySelector('.cell-display').textContent.trim() : td.textContent.trim());
        row.push(text === '—' ? 'NA' : text);
      });
      return row;
    });
  }

  function exportPlanningExcel() {
    if (typeof XLSX === 'undefined') {
      toast('Excel export library failed to load. Please refresh and try again.', true);
      return;
    }

    var rows = boardRows();
    if (!rows.length) {
      toast('No planning rows available to export.', true);
      return;
    }

    function departmentLabel(value) {
      return String(value || 'general').replace(/-/g, ' ').replace(/\b\w/g, function (ch) { return ch.toUpperCase(); });
    }

    function buildCounts(colType) {
      var index = -1;
      for (var i = 0; i < columns.length; i += 1) {
        if (columns[i].type === colType) {
          index = i + 2;
          break;
        }
      }
      var counts = {};
      if (index === -1) return counts;
      rows.forEach(function (row) {
        var key = String(row[index] || '').trim() || 'Unspecified';
        counts[key] = (counts[key] || 0) + 1;
      });
      return counts;
    }

    function countsToMatrix(title, counts) {
      var keys = Object.keys(counts);
      var matrix = [[title], ['Value', 'Count']];
      if (!keys.length) {
        matrix.push(['No data', 0]);
        return matrix;
      }
      keys.sort(function (a, b) { return a.localeCompare(b); }).forEach(function (key) {
        matrix.push([key, counts[key]]);
      });
      return matrix;
    }

    function computeWidths(matrix) {
      var widths = [];
      matrix.forEach(function (row) {
        row.forEach(function (cell, idx) {
          var len = String(cell == null ? '' : cell).length;
          widths[idx] = Math.max(widths[idx] || 0, Math.min(Math.max(len + 2, 10), 42));
        });
      });
      return widths.map(function (wch) { return { wch: wch }; });
    }

    function encode(row, col) {
      return XLSX.utils.encode_cell({ r: row, c: col });
    }

    function ensureCell(wsRef, row, col) {
      var ref = encode(row, col);
      if (!wsRef[ref]) wsRef[ref] = { t: 's', v: '' };
      return wsRef[ref];
    }

    function mergeStyle(base, extra) {
      var out = {};
      Object.keys(base || {}).forEach(function (key) { out[key] = base[key]; });
      Object.keys(extra || {}).forEach(function (key) { out[key] = extra[key]; });
      return out;
    }

    var palette = {
      navy: '173A63',
      blue: '2563EB',
      sky: 'DBEAFE',
      teal: '0F766E',
      mint: 'DCFCE7',
      green: '16A34A',
      amber: 'F59E0B',
      amberSoft: 'FEF3C7',
      red: 'DC2626',
      redSoft: 'FEE2E2',
      slate: '475569',
      slateSoft: 'E2E8F0',
      white: 'FFFFFF',
      panel: 'F8FAFC',
      lavender: 'EEF2FF',
      border: 'CBD5E1'
    };

    var borderAll = {
      top: { style: 'thin', color: { rgb: palette.border } },
      bottom: { style: 'thin', color: { rgb: palette.border } },
      left: { style: 'thin', color: { rgb: palette.border } },
      right: { style: 'thin', color: { rgb: palette.border } }
    };

    var styles = {
      title: {
        font: { bold: true, sz: 18, color: { rgb: palette.white } },
        fill: { fgColor: { rgb: palette.navy } },
        alignment: { horizontal: 'center', vertical: 'center' },
        border: borderAll
      },
      metaLabel: {
        font: { bold: true, color: { rgb: palette.navy } },
        fill: { fgColor: { rgb: palette.sky } },
        alignment: { horizontal: 'left', vertical: 'center' },
        border: borderAll
      },
      metaValue: {
        font: { bold: true, color: { rgb: '0F172A' } },
        fill: { fgColor: { rgb: palette.white } },
        alignment: { horizontal: 'left', vertical: 'center' },
        border: borderAll
      },
      section: {
        font: { bold: true, sz: 13, color: { rgb: palette.white } },
        fill: { fgColor: { rgb: palette.teal } },
        alignment: { horizontal: 'left', vertical: 'center' },
        border: borderAll
      },
      tableHead: {
        font: { bold: true, color: { rgb: palette.white } },
        fill: { fgColor: { rgb: palette.blue } },
        alignment: { horizontal: 'center', vertical: 'center', wrapText: true },
        border: borderAll
      },
      cell: {
        font: { color: { rgb: '0F172A' } },
        fill: { fgColor: { rgb: palette.white } },
        alignment: { horizontal: 'left', vertical: 'center', wrapText: true },
        border: borderAll
      },
      altCell: {
        font: { color: { rgb: '0F172A' } },
        fill: { fgColor: { rgb: palette.panel } },
        alignment: { horizontal: 'left', vertical: 'center', wrapText: true },
        border: borderAll
      },
      countHead: {
        font: { bold: true, color: { rgb: palette.navy } },
        fill: { fgColor: { rgb: palette.slateSoft } },
        alignment: { horizontal: 'center', vertical: 'center' },
        border: borderAll
      },
      countValue: {
        font: { bold: true, color: { rgb: '0F172A' } },
        fill: { fgColor: { rgb: palette.white } },
        alignment: { horizontal: 'left', vertical: 'center' },
        border: borderAll
      },
      countNumber: {
        font: { bold: true, color: { rgb: palette.navy } },
        fill: { fgColor: { rgb: palette.lavender } },
        alignment: { horizontal: 'center', vertical: 'center' },
        border: borderAll
      }
    };

    function statusFill(value) {
      var v = String(value || '').trim().toLowerCase();
      if (v === 'running') return { fg: 'DBEAFE', font: '1D4ED8' };
      if (v === 'completed' || v === 'printing done' || v === 'slitting completed' || v === 'finished') return { fg: 'DCFCE7', font: '166534' };
      if (v.indexOf('hold') === 0) return { fg: 'FEE2E2', font: 'B91C1C' };
      if (v.indexOf('slitting') !== -1) return { fg: 'FFEDD5', font: 'C2410C' };
      return { fg: 'E2E8F0', font: '334155' };
    }

    function priorityFill(value) {
      var v = String(value || '').trim().toLowerCase();
      if (v === 'urgent') return { fg: 'FEE2E2', font: 'B91C1C' };
      if (v === 'high') return { fg: 'FEF3C7', font: 'B45309' };
      if (v === 'normal') return { fg: 'DBEAFE', font: '1D4ED8' };
      return { fg: 'E2E8F0', font: '334155' };
    }

    function applyRowStyle(wsRef, row, colCount, style, startCol) {
      var begin = typeof startCol === 'number' ? startCol : 0;
      for (var col = begin; col < colCount; col += 1) {
        ensureCell(wsRef, row, col).s = style;
      }
    }

    function styleCountTable(wsRef, startRow, counts, colorResolver) {
      var keys = Object.keys(counts);
      ensureCell(wsRef, startRow, 0).s = styles.section;
      ensureCell(wsRef, startRow + 1, 0).s = styles.countHead;
      ensureCell(wsRef, startRow + 1, 1).s = styles.countHead;
      var rowsLocal = keys.length ? keys : ['No data'];
      rowsLocal.forEach(function (key, idx) {
        var rowIdx = startRow + 2 + idx;
        var isEmpty = !keys.length;
        var tone = colorResolver(isEmpty ? '' : key);
        ensureCell(wsRef, rowIdx, 0).s = mergeStyle(styles.countValue, {
          fill: { fgColor: { rgb: tone.fg || palette.white } },
          font: { bold: true, color: { rgb: tone.font || '0F172A' } }
        });
        ensureCell(wsRef, rowIdx, 1).s = styles.countNumber;
      });
      return startRow + 2 + rowsLocal.length;
    }

    var headers = boardHeaders();
    var reportTitle = 'Planning Board Export';
    var deptLabel = departmentLabel(currentDepartment);
    var printedAt = new Date();
    var statusCounts = buildCounts('Status');
    var priorityCounts = buildCounts('Priority');
    var detailData = [
      [reportTitle],
      ['Department', deptLabel, 'Exported At', printedAt.toLocaleString()],
      ['Total Rows', rows.length, 'View', 'Active Planning Board'],
      [],
      headers
    ].concat(rows);
    var ws = XLSX.utils.aoa_to_sheet(detailData);
    ws['!merges'] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: Math.max(headers.length - 1, 0) } }];
    ws['!cols'] = computeWidths(detailData);
    ws['!autofilter'] = { ref: XLSX.utils.encode_range({ s: { r: 4, c: 0 }, e: { r: 4 + rows.length, c: headers.length - 1 } }) };
    ws['!rows'] = [{ hpt: 26 }, { hpt: 22 }, { hpt: 22 }, { hpt: 8 }, { hpt: 24 }];

    applyRowStyle(ws, 0, headers.length, styles.title);
    ensureCell(ws, 1, 0).s = styles.metaLabel;
    ensureCell(ws, 1, 1).s = styles.metaValue;
    ensureCell(ws, 1, 2).s = styles.metaLabel;
    ensureCell(ws, 1, 3).s = styles.metaValue;
    ensureCell(ws, 2, 0).s = styles.metaLabel;
    ensureCell(ws, 2, 1).s = styles.metaValue;
    ensureCell(ws, 2, 2).s = styles.metaLabel;
    ensureCell(ws, 2, 3).s = styles.metaValue;
    applyRowStyle(ws, 4, headers.length, styles.tableHead);

    var statusIndex = -1;
    var priorityIndex = -1;
    columns.forEach(function (col, idx) {
      var absoluteIndex = idx + 2;
      if (col.type === 'Status' && statusIndex === -1) statusIndex = absoluteIndex;
      if (col.type === 'Priority' && priorityIndex === -1) priorityIndex = absoluteIndex;
    });

    rows.forEach(function (row, idx) {
      var rowNumber = 5 + idx;
      var baseStyle = idx % 2 === 0 ? styles.cell : styles.altCell;
      applyRowStyle(ws, rowNumber, headers.length, baseStyle);
      ensureCell(ws, rowNumber, 0).s = mergeStyle(baseStyle, { alignment: { horizontal: 'center', vertical: 'center' } });
      if (statusIndex >= 0) {
        var statusTone = statusFill(row[statusIndex]);
        ensureCell(ws, rowNumber, statusIndex).s = mergeStyle(baseStyle, {
          fill: { fgColor: { rgb: statusTone.fg } },
          font: { bold: true, color: { rgb: statusTone.font } },
          alignment: { horizontal: 'center', vertical: 'center' }
        });
      }
      if (priorityIndex >= 0) {
        var priorityTone = priorityFill(row[priorityIndex]);
        ensureCell(ws, rowNumber, priorityIndex).s = mergeStyle(baseStyle, {
          fill: { fgColor: { rgb: priorityTone.fg } },
          font: { bold: true, color: { rgb: priorityTone.font } },
          alignment: { horizontal: 'center', vertical: 'center' }
        });
      }
    });

    var overviewData = [
      ['Planning Export Overview'],
      ['Department', deptLabel],
      ['Exported At', printedAt.toLocaleString()],
      ['Total Rows', rows.length],
      []
    ].concat(countsToMatrix('Status Summary', statusCounts))
      .concat([[]])
      .concat(countsToMatrix('Priority Summary', priorityCounts));
    var overviewWs = XLSX.utils.aoa_to_sheet(overviewData);
    var statusBlock = countsToMatrix('Status Summary', statusCounts);
    var priorityBlock = countsToMatrix('Priority Summary', priorityCounts);
    var priorityTitleRow = 5 + statusBlock.length + 1;
    overviewWs['!merges'] = [
      { s: { r: 0, c: 0 }, e: { r: 0, c: 1 } },
      { s: { r: 5, c: 0 }, e: { r: 5, c: 1 } },
      { s: { r: priorityTitleRow, c: 0 }, e: { r: priorityTitleRow, c: 1 } }
    ];
    overviewWs['!cols'] = computeWidths(overviewData);
    overviewWs['!rows'] = [{ hpt: 26 }];
    ensureCell(overviewWs, 0, 0).s = styles.title;
    ensureCell(overviewWs, 1, 0).s = styles.metaLabel;
    ensureCell(overviewWs, 1, 1).s = styles.metaValue;
    ensureCell(overviewWs, 2, 0).s = styles.metaLabel;
    ensureCell(overviewWs, 2, 1).s = styles.metaValue;
    ensureCell(overviewWs, 3, 0).s = styles.metaLabel;
    ensureCell(overviewWs, 3, 1).s = styles.metaValue;
    styleCountTable(overviewWs, 5, statusCounts, statusFill);
    styleCountTable(overviewWs, priorityTitleRow, priorityCounts, priorityFill);

    var wb = XLSX.utils.book_new();
    wb.Props = {
      Title: reportTitle,
      Subject: 'Planning board export',
      Author: 'Calipot ERP',
      CreatedDate: printedAt
    };
    XLSX.utils.book_append_sheet(wb, overviewWs, 'Overview');
    XLSX.utils.book_append_sheet(wb, ws, 'Planning Board');

    var fileDept = String(currentDepartment || 'planning').replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '').toLowerCase() || 'planning';
    var stamp = new Date().toISOString().slice(0, 10);
    XLSX.writeFile(wb, 'planning-' + fileDept + '-' + stamp + '.xlsx', { cellStyles: true });
  }

  function printPlanningBoard() {
    var rows = boardRows();
    if (!rows.length) {
      toast('No planning rows available to print.', true);
      return;
    }

    var headers = boardHeaders();
    var title = 'Planning Board - ' + String(currentDepartment || '').replace(/-/g, ' ');
    var printedAt = new Date().toLocaleString();
    var html = '<!doctype html><html><head><meta charset="utf-8">' +
      '<title>' + safeText(title) + '</title>' +
      '<style>' +
      'body{font-family:Arial,sans-serif;margin:24px;color:#0f172a;}' +
      'h1{margin:0 0 6px;font-size:22px;text-transform:capitalize;}' +
      '.meta{margin-bottom:18px;color:#475569;font-size:12px;}' +
      'table{width:100%;border-collapse:collapse;font-size:11px;}' +
      'th,td{border:1px solid #cbd5e1;padding:7px 8px;text-align:left;vertical-align:top;word-break:break-word;}' +
      'th{background:#e2e8f0;font-weight:700;}' +
      'tbody tr:nth-child(even){background:#f8fafc;}' +
      '@media print{body{margin:10mm;} .no-print{display:none;}}' +
      '</style></head><body>' +
      '<h1>' + safeText(title) + '</h1>' +
      '<div class="meta">Printed: ' + safeText(printedAt) + ' | Total Rows: ' + rows.length + '</div>' +
      '<table><thead><tr>' + headers.map(function(h){ return '<th>' + safeText(h) + '</th>'; }).join('') + '</tr></thead><tbody>' +
      rows.map(function(row){
        return '<tr>' + row.map(function(cell){ return '<td>' + safeText(cell || 'NA') + '</td>'; }).join('') + '</tr>';
      }).join('') +
      '</tbody></table>' +
      '<script>window.onload=function(){window.print();};</' + 'script>' +
      '</body></html>';

    var printWin = window.open('', '_blank', 'width=1280,height=900');
    if (!printWin) {
      toast('Popup blocked. Please allow popups and try again.', true);
      return;
    }
    printWin.document.open();
    printWin.document.write(html);
    printWin.document.close();
  }

  function openPlanDetail(tr) {
    var headers = Array.prototype.slice.call(boardTable.querySelectorAll('thead th')).map(function(th){
      return th.textContent.trim();
    });
    var values = [];
    var jobNo = tr.querySelector('.job-no-cell') ? tr.querySelector('.job-no-cell').textContent.trim() : '—';
    values.push({ label: 'Plan No', value: jobNo || '—' });

    Array.prototype.slice.call(tr.querySelectorAll('td[data-key]')).forEach(function(td, idx){
      var value = td.getAttribute('data-raw');
      if (value === null) {
        var disp = td.querySelector('.cell-display');
        value = disp ? disp.textContent.trim() : td.textContent.trim();
      }
      values.push({
        label: (headers[idx + 4] || 'Field').trim(),
        value: value && value !== '—' ? value : 'NA'
      });
    });

    var imageCell = tr.querySelector('.job-image-cell');
    var imageUrl = '';
    if (imageCell) {
      imageUrl = String(imageCell.getAttribute('data-image-url') || '').trim();
      var imageName = imageCell.getAttribute('data-image-name') || '';
      var imageUploadedAt = imageCell.getAttribute('data-image-uploaded-at') || '';
      values.push({ label: 'Job Image', value: imageName !== '' ? imageName : 'Not uploaded' });
      values.push({ label: 'Image Uploaded At', value: imageUploadedAt !== '' ? imageUploadedAt : 'NA' });
    }

    var container = document.getElementById('plan-detail-content');
    var detailHtml = values.map(function(item){
      return '<div class="plan-detail-item">' +
        '<div class="plan-detail-label">' + safeText(item.label) + '</div>' +
        '<div class="plan-detail-value">' + safeText(item.value) + '</div>' +
      '</div>';
    }).join('');

    var imagePreviewHtml = '';
    if (imageUrl !== '') {
      imagePreviewHtml = '' +
        '<div class="plan-detail-item" style="grid-column:1 / -1">' +
          '<div class="plan-detail-label">Job Image Preview</div>' +
          '<div class="plan-detail-value" style="padding-top:8px">' +
            '<img src="' + safeText(imageUrl) + '" alt="Job image preview" style="max-width:100%;max-height:320px;border-radius:10px;border:1px solid #e2e8f0;object-fit:contain;background:#f8fafc">' +
          '</div>' +
        '</div>';
    }

    container.innerHTML = imagePreviewHtml + detailHtml;
    openModal(detailModal);
  }

  var _toastCtr = null;
  function toast(msg, type) {
    var t = (type === true || type === 'error') ? 'error' : (type === 'info' ? 'info' : 'success');
    if (!_toastCtr) { _toastCtr = document.createElement('div'); _toastCtr.id = 'erp-toast-ctr'; document.body.appendChild(_toastCtr); }
    var el = document.createElement('div');
    el.className = 'erp-toast erp-toast-' + t;
    var icon = t === 'error' ? '&#10007;' : '&#10003;';
    el.innerHTML = '<span class="erp-toast-icon">' + icon + '</span><span class="erp-toast-msg">' + String(msg).replace(/&/g,'&amp;').replace(/</g,'&lt;') + '</span><button class="erp-toast-x" type="button">&#215;</button>';
    el.querySelector('.erp-toast-x').onclick = function(){ _dToast(el); };
    _toastCtr.appendChild(el);
    requestAnimationFrame(function(){ el.classList.add('show'); });
    setTimeout(function(){ _dToast(el); }, 5000);
  }
  function _dToast(el) {
    el.classList.remove('show');
    setTimeout(function(){ if (el.parentNode) el.parentNode.removeChild(el); }, 300);
  }

  function confirmDialog(msg, onConfirm) {
    if (!_toastCtr) { _toastCtr = document.createElement('div'); _toastCtr.id = 'erp-toast-ctr'; document.body.appendChild(_toastCtr); }
    var el = document.createElement('div');
    el.className = 'erp-toast erp-toast-confirm show';
    el.innerHTML =
      '<span class="erp-toast-icon">&#9888;</span>' +
      '<span class="erp-toast-msg">' + String(msg).replace(/&/g,'&amp;').replace(/</g,'&lt;') + '</span>' +
      '<button class="erp-confirm-yes btn btn-danger btn-sm" type="button">Delete</button>' +
      '<button class="erp-confirm-no btn btn-ghost btn-sm" type="button">Cancel</button>';
    el.querySelector('.erp-confirm-yes').onclick = function(){ _dToast(el); onConfirm(); };
    el.querySelector('.erp-confirm-no').onclick = function(){ _dToast(el); };
    _toastCtr.appendChild(el);
  }

  function applyRowStatus(tr, val) {
    var vl = String(val || '').trim().toLowerCase();
    var norm = vl.replace(/[^a-z]/g, '');
    var allRowCls = ['row-s-running','row-s-completed','row-s-hold','row-s-slitting','row-s-pending','row-s-printingdone'];
    if (norm.indexOf('printing') !== -1 && (norm.indexOf('done') !== -1 || norm.indexOf('completed') !== -1)) {
      tr.classList.remove.apply(tr.classList, allRowCls);
      tr.classList.add('row-s-printingdone');
      return;
    }
    if (norm.indexOf('slitting') !== -1 || norm.indexOf('sliting') !== -1) {
      tr.classList.remove.apply(tr.classList, allRowCls);
      tr.classList.add(norm.indexOf('completed') !== -1 ? 'row-s-completed' : 'row-s-slitting');
      return;
    }
    var cls = (norm === 'running' || norm === 'inprogress')
      ? 'row-s-running'
      : (norm === 'completed' || norm === 'slittingcompleted')
        ? 'row-s-completed'
        : (norm.indexOf('hold') === 0)
          ? 'row-s-hold'
          : (norm === 'preparingslitting' || norm === 'preparingsliting' || norm === 'preparedslitting' || norm === 'preparedsliting' || norm === 'slitting')
            ? 'row-s-slitting'
            : 'row-s-pending';
    tr.classList.remove.apply(tr.classList, allRowCls);
    tr.classList.add(cls);
  }

  function applyStatusStyle(sel) {
    var v = String(sel.value || '').trim().toLowerCase();
    var norm = v.replace(/[^a-z]/g, '');
    if (norm.indexOf('printing') !== -1 && (norm.indexOf('done') !== -1 || norm.indexOf('completed') !== -1)) {
      sel.className = 'cell-input cell-select-status form-control ssel-printingdone';
      var trPD = sel.closest('tr[data-id]');
      if (trPD) applyRowStatus(trPD, sel.value);
      return;
    }
    if (norm.indexOf('slitting') !== -1 || norm.indexOf('sliting') !== -1) {
      sel.className = 'cell-input cell-select-status form-control ' + ((norm.indexOf('completed') !== -1 || norm.indexOf('done') !== -1) ? 'ssel-completed' : 'ssel-slitting');
      var tr2 = sel.closest('tr[data-id]');
      if (tr2) applyRowStatus(tr2, sel.value);
      return;
    }
    var cls = (norm === 'running' || norm === 'inprogress')
      ? 'ssel-running'
      : (norm === 'completed' || norm === 'slittingcompleted')
        ? 'ssel-completed'
        : (norm.indexOf('hold') === 0)
          ? 'ssel-hold'
          : (norm === 'preparingslitting' || norm === 'preparingsliting' || norm === 'preparedslitting' || norm === 'preparedsliting' || norm === 'slitting')
            ? 'ssel-slitting'
            : 'ssel-pending';
    sel.className = 'cell-input cell-select-status form-control ' + cls;
    var tr = sel.closest('tr[data-id]');
    if (tr) applyRowStatus(tr, sel.value);
  }

  function statusClassFromText(txt) {
    var s = String(txt || '').trim().toLowerCase();
    var n = s.replace(/[^a-z]/g, '');
    if (n.indexOf('printing') !== -1 && (n.indexOf('done') !== -1 || n.indexOf('completed') !== -1)) return 'printingdone';
    if (n.indexOf('slitting') !== -1 || n.indexOf('sliting') !== -1) {
      return (n.indexOf('completed') !== -1 || n.indexOf('done') !== -1) ? 'completed' : 'slitting';
    }
    if (n === 'running' || n === 'inprogress') return 'running';
    if (n === 'completed') return 'completed';
    if (n.indexOf('hold') === 0) return 'hold';
    return 'pending';
  }

  function applyPriorityStyle(sel) {
    var v = String(sel.value || 'Normal').trim().toLowerCase();
    sel.className = 'cell-input cell-select-priority form-control psel-' + v;
  }

  function normalizeRenderedStatuses() {
    boardTable.querySelectorAll('tr[data-id]').forEach(function(tr){
      var statusCell = tr.querySelector('td[data-type="Status"] .cell-display.status-pill');
      if (!statusCell) return;
      var cls = statusClassFromText(statusCell.textContent || 'Pending');
      statusCell.className = 'cell-display status-pill status-pill-' + cls;
      var currentText = String(statusCell.textContent || '').trim();
      var logicalStatus = (cls === 'slitting') ? 'Preparing Slitting' : (cls === 'printingdone') ? 'Printing Done' : currentText;
      if (cls === 'completed' && /slit+ing?\s*done/i.test(currentText)) {
        logicalStatus = 'Slitting Completed';
      }
      applyRowStatus(tr, logicalStatus);
    });
  }

  function postAction(payload) {
    var form = new FormData();
    Object.keys(payload).forEach(function(k){ form.append(k, payload[k]); });
    form.append('csrf_token', csrfToken);
    return fetch(window.location.href, { method: 'POST', body: form }).then(function(r){
      return r.text().then(function(t){
        var data = null;
        try { data = JSON.parse(t); } catch (e) {
          throw new Error('Server returned non-JSON response. ' + String(t || '').slice(0, 180));
        }
        if (!r.ok || !data || data.ok === false) {
          throw new Error((data && data.message) ? data.message : 'Request failed');
        }
        return data;
      });
    });
  }

  function postActionForm(form) {
    form.append('csrf_token', csrfToken);
    return fetch(window.location.href, { method: 'POST', body: form }).then(function(r){
      return r.text().then(function(t){
        var data = null;
        try { data = JSON.parse(t); } catch (e) {
          throw new Error('Server returned non-JSON response. ' + String(t || '').slice(0, 180));
        }
        if (!r.ok || !data || data.ok === false) {
          throw new Error((data && data.message) ? data.message : 'Request failed');
        }
        return data;
      });
    });
  }

  deptSwitch.addEventListener('change', function(){
    var url = new URL(window.location.href);
    url.searchParams.set('department', deptSwitch.value);
    window.location.href = url.toString();
  });

  function setRowEditMode(tr, on) {
    tr.classList.toggle('is-editing', on);
    tr.querySelector('.btn-edit').style.display = on ? 'none' : '';
    tr.querySelector('.btn-delete').style.display = on ? 'none' : '';
    tr.querySelector('.btn-save').style.display = on ? '' : 'none';
    tr.querySelector('.btn-cancel').style.display = on ? '' : 'none';

    tr.querySelectorAll('td[data-key]').forEach(function(td){
      var key = td.getAttribute('data-key');
      var disp = td.querySelector('.cell-display');
      var input = td.querySelector('.cell-input');
      if (key === 'sn') return;
      disp.style.display = on ? 'none' : '';
      input.style.display = on ? '' : 'none';

      var type = td.getAttribute('data-type');
      if (input.tagName !== 'SELECT') {
        if (type === 'Date') input.type = 'date';
        else if (type === 'Number') input.type = 'number';
        else input.type = 'text';
      }

      if (on) {
        var current = td.getAttribute('data-raw') || disp.textContent.trim();
        if (current === '—') current = '';
        input.value = current;
        if (type === 'Status' && input.tagName === 'SELECT') {
          applyStatusStyle(input);
          input.onchange = function(){ applyStatusStyle(this); };
        }
        if (type === 'Priority' && input.tagName === 'SELECT') {
          applyPriorityStyle(input);
          input.onchange = function(){ applyPriorityStyle(this); };
        }
      }
    });
  }

  function updateImageZoom(scale) {
    imageViewerScale = Math.max(0.25, Math.min(5, scale));
    if (imageViewerImg) {
      imageViewerImg.style.transform = 'scale(' + imageViewerScale + ')';
      imageViewerImg.style.transformOrigin = 'center center';
    }
    if (imageZoomResetBtn) {
      imageZoomResetBtn.textContent = Math.round(imageViewerScale * 100) + '%';
    }
  }

  function setRowImageData(tr, meta) {
    var cell = tr.querySelector('.job-image-cell');
    if (!cell) return;

    var imagePath = String(meta.image_path || '').trim();
    var imageUrl = String(meta.image_url || '').trim();
    var imageName = String(meta.image_name || '').trim();
    var imageUploadedAt = String(meta.image_uploaded_at || '').trim();

    cell.setAttribute('data-image-path', imagePath);
    cell.setAttribute('data-image-url', imageUrl);
    cell.setAttribute('data-image-name', imageName);
    cell.setAttribute('data-image-uploaded-at', imageUploadedAt);

    var box = cell.querySelector('.job-image-box');
    if (!box) return;

    if (imageUrl !== '') {
      box.classList.remove('no-image');
      box.classList.add('has-image');
      box.innerHTML = '' +
        '<button type="button" class="job-image-thumb-btn" title="Open image">' +
          '<img src="' + safeText(imageUrl) + '" alt="Job image" class="job-image-thumb">' +
        '</button>';
      return;
    }

    box.classList.remove('has-image');
    box.classList.add('no-image');
    box.innerHTML = '' +
      '<button type="button" class="job-image-empty-btn" title="Add image"><i class="bi bi-image"></i></button>';
  }

  function openImageViewerForRow(tr) {
    var cell = tr.querySelector('.job-image-cell');
    if (!cell) return;
    var imageUrl = String(cell.getAttribute('data-image-url') || '').trim();
    var imageName = String(cell.getAttribute('data-image-name') || '').trim();
    var imageUploadedAt = String(cell.getAttribute('data-image-uploaded-at') || '').trim();
    var jobNo = tr.querySelector('.job-no-cell strong') ? tr.querySelector('.job-no-cell strong').textContent.trim() : '';

    imageViewerRowId = tr.getAttribute('data-id') || '';
    if (imageUrl !== '') {
      imageViewerImg.src = imageUrl;
      imageViewerImg.style.display = '';
      imageViewerStage.classList.remove('is-empty');
      imageViewerStage.setAttribute('data-empty', '');
      imageDeleteBtn.disabled = false;
    } else {
      imageViewerImg.removeAttribute('src');
      imageViewerImg.style.display = 'none';
      imageViewerStage.classList.add('is-empty');
      imageViewerStage.setAttribute('data-empty', 'No image uploaded. Click Upload or Edit to add one.');
      imageDeleteBtn.disabled = true;
    }

    imageViewerMeta.innerHTML = '<strong>' + safeText(jobNo || 'Planning Job') + '</strong>' +
      (imageName !== '' ? '<span>' + safeText(imageName) + '</span>' : '') +
      (imageUploadedAt !== '' ? '<small>Uploaded: ' + safeText(imageUploadedAt) + '</small>' : '');
    updateImageZoom(1);
    openModal(imageViewerModal);
  }

  function uploadImageForRow(tr, file) {
    var rowId = tr.getAttribute('data-id');
    if (!rowId || !file) return;
    var form = new FormData();
    form.append('action', 'upload_job_image');
    form.append('id', rowId);
    form.append('job_image', file);
    postActionForm(form).then(function(res){
      setRowImageData(tr, res || {});
      toast('Job image uploaded');
      if (imageViewerModal.style.display === 'flex') {
        openImageViewerForRow(tr);
      }
    }).catch(function(err){
      toast(err.message || 'Image upload failed', true);
    });
  }

  function removeImageForRow(tr) {
    var rowId = tr.getAttribute('data-id');
    if (!rowId) return;
    confirmDialog('Delete this planning job image?', function(){
      postAction({ action: 'delete_job_image', id: rowId }).then(function(){
        setRowImageData(tr, {});
        if (imageViewerModal && imageViewerModal.style.display === 'flex') {
          closeModal(imageViewerModal);
        }
        toast('Job image removed');
      }).catch(function(err){
        toast(err.message || 'Unable to delete image', true);
      });
    });
  }

  boardTable.addEventListener('click', function(e){
    var tr = e.target.closest('tr[data-id]');
    if (!tr) return;

    if (e.target.closest('.job-image-thumb-btn,.job-image-empty-btn')) {
      openImageViewerForRow(tr);
      return;
    }

    if (e.target.closest('.job-no-cell')) {
      openPlanDetail(tr);
      return;
    }

    if (e.target.closest('.btn-edit')) {
      setRowEditMode(tr, true);
      return;
    }

    if (e.target.closest('.btn-cancel')) {
      setRowEditMode(tr, false);
      return;
    }

    if (e.target.closest('.btn-delete')) {
      var rowId = tr.getAttribute('data-id');
      var rowTr = tr;
      confirmDialog('Delete this planning row?', function(){
        postAction({ action: 'delete_row', id: rowId }).then(function(){
          rowTr.remove();
          toast('Row deleted');
        }).catch(function(err){ toast(err.message || 'Delete failed', true); });
      });
      return;
    }

    if (e.target.closest('.btn-save')) {
      var payload = { action: 'save_row', id: tr.getAttribute('data-id') };
      var rowValues = {};
      tr.querySelectorAll('td[data-key]').forEach(function(td){
        var key = td.getAttribute('data-key');
        if (key === 'sn') return;
        rowValues[key] = td.querySelector('.cell-input').value || '';
        payload[key] = rowValues[key];
      });
      payload.row_values_json = JSON.stringify(rowValues);
      postAction(payload).then(function(){
        tr.querySelectorAll('td[data-key]').forEach(function(td){
          var key = td.getAttribute('data-key');
          var type = td.getAttribute('data-type');
          var disp = td.querySelector('.cell-display');
          var input = td.querySelector('.cell-input');
          if (key === 'sn') return;

          var v = input.value || '';
          td.setAttribute('data-raw', v);
          if (type === 'Status') {
            var vl = String(v || 'Pending').trim().toLowerCase().replace(/[^a-z]/g,'');
            var pilClass = (vl.indexOf('slitting') !== -1 || vl.indexOf('sliting') !== -1)
              ? (vl.indexOf('completed') !== -1 ? 'completed' : 'slitting')
              : (vl === 'running' || vl === 'inprogress')
              ? 'running'
              : (vl === 'completed' || vl === 'slittingcompleted')
                ? 'completed'
                : (vl.indexOf('hold') === 0)
                  ? 'hold'
                  : (vl === 'preparingslitting' || vl === 'preparingsliting' || vl === 'preparedslitting' || vl === 'preparedsliting' || vl === 'slitting')
                    ? 'slitting'
                    : 'pending';
            disp.className = 'cell-display status-pill status-pill-' + pilClass;
            disp.textContent = v || 'Pending';
            applyRowStatus(tr, v);
          } else if (type === 'Priority') {
            var pCls = String(v || 'Normal').trim().toLowerCase();
            disp.className = 'cell-display priority-pill priority-pill-' + pCls;
            disp.textContent = v || 'Normal';
          } else {
            disp.textContent = v || '—';
          }
        });

        setRowEditMode(tr, false);
        toast('Plan saved');
      }).catch(function(err){ toast(err.message || 'Save failed', true); });
      return;
    }
  });

  boardTable.addEventListener('dblclick', function(e){
    if (!CAN_EDIT) return;
    if (e.target.closest('.btn-edit,.btn-save,.btn-cancel,.btn-delete,.job-image-thumb-btn,.job-image-empty-btn,.seq-drag-handle')) return;
    var tr = e.target.closest('tr[data-id]');
    if (!tr || tr.classList.contains('is-editing')) return;
    setRowEditMode(tr, true);
  });

  // Final UI guard: ensure persisted/legacy statuses render with the correct color after refresh.
  normalizeRenderedStatuses();

  function openModal(el) { el.style.display = 'flex'; }
  function closeModal(el) {
    el.style.display = 'none';
    if (el === importMapModal) {
      pendingImportRows = [];
      pendingImportHeaders = [];
      importMapList.innerHTML = '';
      fileInput.value = '';
    }
    if (el === imageViewerModal) {
      imageViewerRowId = '';
      imageViewerImg.removeAttribute('src');
      imageViewerImg.style.display = '';
      imageViewerStage.classList.remove('is-empty');
      imageViewerStage.setAttribute('data-empty', '');
      imageDeleteBtn.disabled = false;
      imageViewerMeta.textContent = '';
      updateImageZoom(1);
    }
  }

  imageZoomInBtn.addEventListener('click', function(){ updateImageZoom(imageViewerScale + 0.25); });
  imageZoomOutBtn.addEventListener('click', function(){ updateImageZoom(imageViewerScale - 0.25); });
  imageZoomResetBtn.addEventListener('click', function(){ updateImageZoom(1); });
  imageUploadBtn.addEventListener('click', function(){
    if (!imageViewerRowId) return;
    var row = boardTable.querySelector('tr[data-id="' + imageViewerRowId + '"]');
    if (!row) return;
    imageUploadInput.value = '';
    imageUploadInput.onchange = function(){
      var file = imageUploadInput.files && imageUploadInput.files[0];
      if (!file) return;
      uploadImageForRow(row, file);
    };
    imageUploadInput.click();
  });
  imageEditBtn.addEventListener('click', function(){
    if (!imageViewerRowId) return;
    var row = boardTable.querySelector('tr[data-id="' + imageViewerRowId + '"]');
    if (!row) return;
    imageUploadInput.value = '';
    imageUploadInput.onchange = function(){
      var file = imageUploadInput.files && imageUploadInput.files[0];
      if (!file) return;
      uploadImageForRow(row, file);
    };
    imageUploadInput.click();
  });
  imageDeleteBtn.addEventListener('click', function(){
    if (!imageViewerRowId) return;
    var row = boardTable.querySelector('tr[data-id="' + imageViewerRowId + '"]');
    if (!row) return;
    removeImageForRow(row);
  });

  document.getElementById('btn-add-row').addEventListener('click', function(){ openModal(addModal); });
  btnExportExcel.addEventListener('click', exportPlanningExcel);
  btnPrintPdf.addEventListener('click', printPlanningBoard);
  document.getElementById('btn-board-config').addEventListener('click', function(){
    renderConfigList();
    openModal(cfgModal);
  });

  document.querySelectorAll('.modal-close').forEach(function(btn){
    btn.addEventListener('click', function(){
      closeModal(btn.closest('.planning-modal'));
    });
  });

  [addModal, cfgModal, importMapModal, detailModal, imageViewerModal].forEach(function(m){
    m.addEventListener('click', function(e){ if (e.target === m) closeModal(m); });
  });

  document.getElementById('form-add-row').addEventListener('submit', function(e){
    e.preventDefault();
    var fd = new FormData(e.target);
    var payload = { action: 'create_row' };
    var rowValues = {};
    var jobImage = fd.get('job_image');
    fd.forEach(function(v, k){
      if (k === 'job_image') return;
      payload[k] = v;
      rowValues[k] = v;
    });
    payload.row_values_json = JSON.stringify(rowValues);

    postAction(payload).then(function(res){
      var createdId = parseInt(res && res.id ? res.id : '0', 10);
      if (jobImage && typeof jobImage === 'object' && jobImage.size > 0 && createdId > 0) {
        var upForm = new FormData();
        upForm.append('action', 'upload_job_image');
        upForm.append('id', String(createdId));
        upForm.append('job_image', jobImage);
        return postActionForm(upForm).then(function(){
          toast('New job added with image');
          window.location.reload();
        });
      }
      toast('New job added');
      window.location.reload();
    }).catch(function(err){ toast(err.message || 'Create failed', true); });
  });

  document.getElementById('btn-import').addEventListener('click', function(){ fileInput.click(); });

  function normKey(v) {
    return String(v == null ? '' : v).replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function importTargetOptions() {
    var built = {};
    var out = [];

    columns.forEach(function(col){
      if (!col || !col.key || col.key === 'sn') return;
      var key = String(col.key);
      if (built[key]) return;
      built[key] = true;
      out.push({ key: key, label: String(col.label || key) });
    });

    [
      { key: 'name', label: 'Job Name' },
      { key: 'dispatch_date', label: 'Dispatch Date' },
      { key: 'order_date', label: 'Order Date' },
      { key: 'remarks', label: 'Remarks' },
      { key: 'priority', label: 'Priority' },
      { key: 'machine', label: 'Machine' },
      { key: 'operator_name', label: 'Operator Name' }
    ].forEach(function(t){
      if (!built[t.key]) {
        built[t.key] = true;
        out.push(t);
      }
    });

    return out;
  }

  function suggestImportTarget(header, targets) {
    var n = normKey(header).replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
    var nSimple = n.replace(/_/g, '');
    var map = {
      name: ['name', 'jobname', 'job_name'],
      dispatch_date: ['dispatchdate', 'dispatch_date', 'dateofdispatch'],
      order_date: ['orderdate', 'order_date'],
      printing_planning: ['printingplanning', 'printing_planing', 'planning', 'status', 'planing'],
      plate_no: ['plateno', 'plate_no', 'plate'],
      size: ['size', 'labelsize', 'label_size'],
      repeat: ['repeat', 'repeatmm', 'repeat_mm'],
      material: ['material'],
      paper_size: ['papersize', 'paper_size'],
      die: ['die'],
      allocate_mtrs: ['allocatemtrs', 'allocate_mtrs', 'mtrs', 'allocatemeters'],
      qty_pcs: ['qtypcs', 'qty_pcs', 'qty', 'quantity'],
      core_size: ['coresize', 'core_size', 'core'],
      qty_per_roll: ['qtyperroll', 'qty_per_roll', 'qtyroll'],
      roll_direction: ['rolldirection', 'roll_direction', 'direction'],
      remarks: ['remarks', 'notes'],
      machine: ['machine'],
      operator_name: ['operatorname', 'operator_name', 'operator'],
      priority: ['priority']
    };

    for (var key in map) {
      if (!Object.prototype.hasOwnProperty.call(map, key)) continue;
      if (map[key].indexOf(nSimple) !== -1 || map[key].indexOf(n) !== -1) return key;
    }

    var byKey = targets.find(function(t){ return normKey(t.key).replace(/[^a-z0-9]+/g, '') === nSimple; });
    if (byKey) return byKey.key;
    var byLabel = targets.find(function(t){ return normKey(t.label).replace(/[^a-z0-9]+/g, '') === nSimple; });
    if (byLabel) return byLabel.key;
    return '';
  }

  function openImportMapping(headers, rows) {
    var targets = importTargetOptions();
    pendingImportHeaders = headers.slice();
    pendingImportRows = rows.slice();
    importMapList.innerHTML = '';

    headers.forEach(function(h){
      var row = document.createElement('div');
      row.className = 'import-map-row';

      var source = document.createElement('div');
      source.className = 'import-map-src';
      source.textContent = String(h || '(blank header)');

      var select = document.createElement('select');
      select.className = 'form-control import-map-select';
      select.setAttribute('data-source-header', String(h || ''));
      select.innerHTML = '<option value="">Ignore this column</option>';
      targets.forEach(function(t){
        select.innerHTML += '<option value="' + safeText(t.key) + '">' + safeText(t.label) + ' (' + safeText(t.key) + ')</option>';
      });

      var guess = suggestImportTarget(h, targets);
      if (guess) select.value = guess;

      row.appendChild(source);
      row.appendChild(select);
      importMapList.appendChild(row);
    });

    openModal(importMapModal);
  }

  function runMappedImport() {
    var map = {};
    importMapList.querySelectorAll('select[data-source-header]').forEach(function(sel){
      var src = String(sel.getAttribute('data-source-header') || '');
      var dst = String(sel.value || '');
      if (src !== '' && dst !== '') map[src] = dst;
    });

    var normalizedRows = pendingImportRows.map(function(raw){
      var out = {};
      Object.keys(raw || {}).forEach(function(srcKey){
        var dstKey = map[srcKey] || '';
        if (!dstKey) return;
        out[dstKey] = raw[srcKey];
      });
      return out;
    }).filter(function(r){
      return Object.keys(r).length > 0;
    });

    if (!normalizedRows.length) {
      toast('No mapped columns selected for import.', true);
      return;
    }

    var hasJobName = normalizedRows.some(function(r){
      return String(r.name == null ? '' : r.name).trim() !== '';
    });
    if (!hasJobName) {
      toast('Map at least one Excel column to Job Name (name).', true);
      return;
    }

    postAction({ action: 'import_rows', rows_json: JSON.stringify(normalizedRows) }).then(function(res){
      closeModal(importMapModal);
      toast('Import successful: ' + (res.count || 0) + ' rows');
      window.location.reload();
    }).catch(function(err){
      toast(err.message || 'Import failed', true);
    });
  }

  fileInput.addEventListener('change', function(e){
    var file = e.target.files && e.target.files[0];
    if (!file) return;
    if (typeof XLSX === 'undefined') {
      toast('Excel reader failed to load. Please refresh and try again.', true);
      return;
    }

    var reader = new FileReader();
    reader.onload = function(evt){
      try {
        var wb = XLSX.read(evt.target.result, { type: 'array' });
        var ws = wb.Sheets[wb.SheetNames[0]];
        var matrix = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
        if (!Array.isArray(matrix) || matrix.length < 2) {
          toast('No data rows found in file', true);
          return;
        }

        var headers = (matrix[0] || []).map(function(h, idx){
          var v = String(h == null ? '' : h).trim();
          return v !== '' ? v : ('Column ' + (idx + 1));
        });

        var rows = matrix.slice(1).map(function(cells){
          var rowObj = {};
          headers.forEach(function(h, idx){
            rowObj[h] = (cells && typeof cells[idx] !== 'undefined') ? cells[idx] : '';
          });
          return rowObj;
        }).filter(function(rowObj){
          return Object.keys(rowObj).some(function(k){
            return String(rowObj[k] == null ? '' : rowObj[k]).trim() !== '';
          });
        });

        if (!rows.length) {
          toast('No data rows found in file', true);
          return;
        }

        openImportMapping(headers, rows);
      } catch (err) {
        toast('Unable to read Excel file: ' + (err && err.message ? err.message : 'unknown error'), true);
      } finally {
        if (importMapModal.style.display !== 'flex') {
          fileInput.value = '';
        }
      }
    };
    reader.readAsArrayBuffer(file);
  });

  btnImportMapApply.addEventListener('click', runMappedImport);
  btnImportMapCancel.addEventListener('click', function(){ closeModal(importMapModal); });

  function renderConfigList() {
    var list = document.getElementById('config-list');
    list.innerHTML = '';
    columns.forEach(function(col, idx){
      var row = document.createElement('div');
      row.className = 'config-row';
      row.setAttribute('draggable', 'true');
      row.dataset.index = String(idx);

      row.innerHTML = '' +
        '<div class="config-drag"><i class="bi bi-grip-horizontal"></i></div>' +
        '<input class="form-control config-label" value="' + String(col.label || '').replace(/"/g, '&quot;') + '">' +
        '<select class="form-control config-type">' +
          '<option value="Text">Text</option>' +
          '<option value="Number">Number</option>' +
          '<option value="Date">Date</option>' +
          '<option value="Status">Status</option>' +
          '<option value="Priority">Priority</option>' +
        '</select>';

      row.querySelector('.config-type').value = col.type || 'Text';
      list.appendChild(row);
    });

    var dragIdx = -1;
    list.querySelectorAll('.config-row').forEach(function(row){
      row.addEventListener('dragstart', function(){ dragIdx = parseInt(row.dataset.index || '-1', 10); });
      row.addEventListener('dragover', function(e){ e.preventDefault(); });
      row.addEventListener('drop', function(){
        var overIdx = parseInt(row.dataset.index || '-1', 10);
        if (dragIdx < 0 || overIdx < 0 || dragIdx === overIdx) return;
        var moved = columns.splice(dragIdx, 1)[0];
        columns.splice(overIdx, 0, moved);
        renderConfigList();
      });
    });
  }

  document.getElementById('btn-save-config').addEventListener('click', function(){
    var rows = Array.prototype.slice.call(document.querySelectorAll('#config-list .config-row'));
    rows.forEach(function(r, idx){
      var label = r.querySelector('.config-label').value.trim();
      var type = r.querySelector('.config-type').value;
      if (columns[idx]) {
        columns[idx].label = label || columns[idx].label;
        columns[idx].type = type || columns[idx].type;
      }
    });

    postAction({ action: 'save_columns', columns_json: JSON.stringify(columns) }).then(function(){
      toast('Board headers updated');
      window.location.reload();
    }).catch(function(err){ toast(err.message || 'Save failed', true); });
  });

  // ── Column-header drag-to-reorder ──────────────────────────
  var colDragFromIdx = -1;
  function initColDrag() {
    var colThs = Array.prototype.slice.call(boardTable.querySelectorAll('thead tr th[data-col-key]'));
    colThs.forEach(function(th) {
      th.ondragstart = function(e) {
        var cur = Array.prototype.slice.call(boardTable.querySelectorAll('thead tr th[data-col-key]'));
        colDragFromIdx = cur.indexOf(th);
        e.dataTransfer.effectAllowed = 'move';
        th.classList.add('col-dragging');
      };
      th.ondragend = function() { th.classList.remove('col-dragging'); colThs.forEach(function(x){ x.classList.remove('col-drag-over'); }); };
      th.ondragover = function(e) { e.preventDefault(); th.classList.add('col-drag-over'); };
      th.ondragleave = function() { th.classList.remove('col-drag-over'); };
      th.ondrop = function(e) {
        e.preventDefault();
        th.classList.remove('col-drag-over');
        var cur = Array.prototype.slice.call(boardTable.querySelectorAll('thead tr th[data-col-key]'));
        var dropIdx = cur.indexOf(th);
        if (colDragFromIdx < 0 || colDragFromIdx === dropIdx) return;
        // Reorder columns array
        var moved = columns.splice(colDragFromIdx, 1)[0];
        columns.splice(dropIdx, 0, moved);
        // Move th in DOM
        var theadTr = boardTable.querySelector('thead tr');
        var allThs = Array.prototype.slice.call(theadTr.querySelectorAll('th[data-col-key]'));
        var fromTh = allThs[colDragFromIdx];
        if (colDragFromIdx < dropIdx) theadTr.insertBefore(fromTh, th.nextSibling);
        else theadTr.insertBefore(fromTh, th);
        // Move tds in every data row
        boardTable.querySelectorAll('tbody tr[data-id]').forEach(function(tr) {
          var tds = Array.prototype.slice.call(tr.querySelectorAll('td[data-key]'));
          var fromTd = tds[colDragFromIdx];
          var toTd = tds[dropIdx];
          if (colDragFromIdx < dropIdx) tr.insertBefore(fromTd, toTd.nextSibling);
          else tr.insertBefore(fromTd, toTd);
        });
        var from = colDragFromIdx;
        colDragFromIdx = -1;
        initColDrag();
        // Persist new order
        postAction({ action: 'save_columns', columns_json: JSON.stringify(columns) }).then(function(){
          toast('Column order saved');
        }).catch(function(err){ toast(err.message, 'error'); });
      };
    });
  }
  initColDrag();

  // ── Row drag-to-reorder ──────────────────────────
  var rowDragFrom = null;
  var rowDragGrip = false;
  function initRowDrag() {
    boardTable.querySelectorAll('tbody tr[data-id]').forEach(function(tr) {
      tr.onmousedown = function(e) {
        rowDragGrip = !!e.target.closest('.seq-drag-handle');
      };
      tr.ondragstart = function(e) {
        if (!rowDragGrip) { e.preventDefault(); return; }
        rowDragFrom = tr;
        tr.classList.add('row-dragging');
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', tr.getAttribute('data-id'));
      };
      tr.ondragend = function() {
        tr.classList.remove('row-dragging');
        boardTable.querySelectorAll('tbody tr.row-drag-over').forEach(function(x){ x.classList.remove('row-drag-over'); });
        rowDragFrom = null;
        rowDragGrip = false;
      };
      tr.ondragover = function(e) {
        if (!rowDragFrom) return;
        e.preventDefault();
        boardTable.querySelectorAll('tbody tr.row-drag-over').forEach(function(x){ x.classList.remove('row-drag-over'); });
        tr.classList.add('row-drag-over');
      };
      tr.ondragleave = function() { tr.classList.remove('row-drag-over'); };
      tr.ondrop = function(e) {
        e.preventDefault();
        tr.classList.remove('row-drag-over');
        if (!rowDragFrom || rowDragFrom === tr) return;
        var tbody = boardTable.querySelector('tbody');
        var allRows = Array.prototype.slice.call(tbody.querySelectorAll('tr[data-id]'));
        var fromIdx = allRows.indexOf(rowDragFrom);
        var toIdx = allRows.indexOf(tr);
        if (fromIdx < 0 || toIdx < 0) return;
        if (fromIdx < toIdx) {
          tbody.insertBefore(rowDragFrom, tr.nextSibling);
        } else {
          tbody.insertBefore(rowDragFrom, tr);
        }
        rowDragFrom = null;
        // Renumber S.N column (index 2: drag-col, actions, S.N)
        var newRows = Array.prototype.slice.call(tbody.querySelectorAll('tr[data-id]'));
        var order = [];
        newRows.forEach(function(r, i) {
          r.children[2].textContent = String(i + 1);
          order.push(r.getAttribute('data-id'));
        });
        // Save new sequence order
        postAction({ action: 'reorder_rows', order_json: JSON.stringify(order) }).then(function(){
          toast('Sequence updated');
        }).catch(function(err){ toast(err.message || 'Reorder failed', true); });
      };
    });
  }
  initRowDrag();
})();
</script>

<style>
.planning-view-switch {
  display: inline-flex;
  gap: 8px;
  margin: 0 0 14px;
  flex-wrap: wrap;
}
.planning-view-link {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 9px 14px;
  border-radius: 999px;
  border: 1px solid #dbe5f0;
  background: #fff;
  color: #334155;
  font-size: .82rem;
  font-weight: 700;
  text-decoration: none;
}
.planning-view-link:hover {
  border-color: #93c5fd;
  color: #1d4ed8;
}
.planning-view-link.is-active {
  background: #eff6ff;
  border-color: #bfdbfe;
  color: #1d4ed8;
}
.planning-board-wrap { max-height: 74vh; overflow: auto; }
.planning-board-table { min-width: 1700px; }
.planning-board-table th,
.planning-board-table td { white-space: nowrap; }
.planning-board-table th[draggable="true"] { cursor: move; }
.planning-board-table tr.is-editing { background: #f8fafc; }
.planning-board-table tr.is-editing td { white-space: normal; }
.planning-board-table tr.is-editing .cell-input {
  display: block !important;
  width: 100%;
  min-width: 120px;
  box-sizing: border-box;
}
.planning-board-table tr.is-editing td[data-type="Date"] .cell-input { min-width: 140px; }
.planning-board-table tr.is-editing td[data-type="Number"] .cell-input { min-width: 80px; }
.planning-board-table td[data-key] { min-width: 80px; }
.sticky-col {
  position: sticky;
  left: 0;
  z-index: 4;
  background: #fff;
  min-width: 145px;
}
.planning-board-table thead .sticky-col { z-index: 6; }
.job-no-cell { white-space: nowrap; color: #1e40af; font-size: .82rem; letter-spacing: .02em; }
.job-no-cell strong { cursor: pointer; text-decoration: underline; text-underline-offset: 2px; }
.job-image-cell { min-width: 74px; text-align: center; }
.job-image-box {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 44px;
}
.job-image-thumb-btn {
  border: none;
  padding: 0;
  background: transparent;
  cursor: zoom-in;
}
.job-image-thumb {
  width: 56px;
  height: 40px;
  object-fit: cover;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  box-shadow: 0 2px 6px rgba(2, 6, 23, .12);
}
.job-image-empty-btn {
  width: 56px;
  height: 40px;
  border: 1px dashed #cbd5e1;
  border-radius: 6px;
  background: #f8fafc;
  color: #64748b;
  cursor: pointer;
}

.job-image-empty-btn:hover,
.job-image-thumb-btn:hover .job-image-thumb { border-color: #60a5fa; }

.image-viewer-modal-card {
  width: min(760px, 100%);
}
.image-viewer-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 10px 16px;
  border-bottom: 1px solid #e2e8f0;
}
.image-viewer-meta {
  display: flex;
  flex-direction: column;
  gap: 2px;
  color: #334155;
}
.image-viewer-meta strong {
  font-size: .9rem;
  color: #0f172a;
}
.image-viewer-meta span,
.image-viewer-meta small {
  font-size: .76rem;
}
.image-viewer-controls {
  display: flex;
  gap: 6px;
}
.image-viewer-stage {
  background: #0f172a;
  min-height: 42vh;
  max-height: 52vh;
  overflow: auto;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 18px;
}
.image-viewer-stage.is-empty::before {
  content: attr(data-empty);
  color: #cbd5e1;
  font-size: .92rem;
}
.image-viewer-stage img {
  max-width: 100%;
  max-height: 100%;
  border-radius: 8px;
  box-shadow: 0 18px 38px rgba(15, 23, 42, .5);
  transition: transform .16s ease;
}

.planning-modal {
  position: fixed;
  inset: 0;
  background: rgba(15, 23, 42, .42);
  z-index: 1200;
  align-items: center;
  justify-content: center;
  padding: 20px;
}
.planning-modal-card {
  width: min(920px, 100%);
  max-height: 88vh;
  overflow: auto;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 22px 54px rgba(0,0,0,.22);
  border: 1px solid #e5e7eb;
}
.planning-modal-head,
.planning-modal-foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 16px;
  border-bottom: 1px solid #eef2f7;
}
.planning-modal-foot {
  border-bottom: none;
  border-top: 1px solid #eef2f7;
}
.planning-modal-head h3 { font-size: 1.05rem; }
.planning-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
  padding: 14px 16px;
}
.planning-job-preview-box {
  margin: 14px 16px 0;
  padding: 12px 14px;
  border: 1px solid #dbeafe;
  background: #eff6ff;
  border-radius: 10px;
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}
.planning-job-preview-label {
  font-size: .72rem;
  font-weight: 700;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: #1d4ed8;
}
.planning-job-preview-box strong {
  font-size: 1rem;
  color: #0f172a;
}
.planning-job-preview-box small {
  color: #475569;
}
.planning-grid label {
  display: block;
  margin-bottom: 5px;
  font-size: .75rem;
  font-weight: 700;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: .04em;
}
.config-list { padding: 14px 16px; display: grid; gap: 8px; }
.import-map-list {
  padding: 14px 16px;
  display: grid;
  gap: 8px;
  max-height: 52vh;
  overflow: auto;
}
.import-map-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  align-items: center;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  background: #f8fafc;
  padding: 8px 10px;
}
.import-map-src {
  font-size: .8rem;
  color: #0f172a;
  font-weight: 700;
  word-break: break-word;
}
.plan-detail-grid {
  padding: 16px;
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}
.plan-detail-item {
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  padding: 12px;
  background: #f8fafc;
}
.plan-detail-label {
  font-size: .72rem;
  text-transform: uppercase;
  letter-spacing: .06em;
  color: #64748b;
  font-weight: 700;
  margin-bottom: 6px;
}
.plan-detail-value {
  color: #0f172a;
  font-weight: 600;
  word-break: break-word;
}
.config-row {
  display: grid;
  grid-template-columns: 34px 1fr 150px;
  gap: 8px;
  align-items: center;
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 8px;
}
.config-drag {
  height: 34px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #94a3b8;
}
@media (max-width: 980px) {
  .planning-grid { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 680px) {
  .planning-grid { grid-template-columns: 1fr; }
  .import-map-row { grid-template-columns: 1fr; }
  .plan-detail-grid { grid-template-columns: 1fr; }
  .job-image-cell { min-width: 64px; }
  .job-image-thumb,
  .job-image-empty-btn { width: 48px; height: 34px; }
  .image-viewer-stage { min-height: 36vh; }
}
/* ── In-page toast notifications ── */
#erp-toast-ctr { position: fixed; bottom: 24px; right: 24px; z-index: 9999; display: flex; flex-direction: column; gap: 10px; pointer-events: none; max-width: 420px; }
.erp-toast { display: flex; align-items: center; gap: 10px; padding: 12px 18px; border-radius: 8px; font-size: .875rem; font-weight: 500; box-shadow: 0 4px 20px rgba(0,0,0,.18); pointer-events: auto; opacity: 0; transform: translateX(48px); transition: opacity .28s ease, transform .28s ease; color: #fff; }
.erp-toast.show { opacity: 1; transform: translateX(0); }
.erp-toast-success { background: #16a34a; }
.erp-toast-error { background: #dc2626; }
.erp-toast-info { background: #0284c7; }
.erp-toast-icon { font-size: .95rem; font-weight: 900; flex-shrink: 0; }
.erp-toast-msg { flex: 1; line-height: 1.45; word-break: break-word; }
.erp-toast-x { background: none; border: none; color: inherit; font-size: 1.2rem; cursor: pointer; opacity: .8; padding: 0 0 0 6px; line-height: 1; }
.erp-toast-x:hover { opacity: 1; }
.erp-toast-confirm { gap: 10px; flex-wrap: wrap; background: #1e293b; }
.erp-toast-confirm .erp-toast-msg { color: #f1f5f9; }
.erp-toast-confirm .erp-toast-icon { color: #fbbf24; font-size: 1rem; }
.erp-confirm-yes, .erp-confirm-no { flex-shrink: 0; font-size: .78rem !important; padding: 4px 12px !important; }
/* ── Status select inline edit ── */
.cell-select-status { -webkit-appearance: none; appearance: none; font-size: .78rem; font-weight: 700; text-align: center; border-radius: 4px !important; padding: 3px 14px !important; cursor: pointer; min-width: 130px; border-width: 0 !important; }
.ssel-running  { background: #3b82f6 !important; color: #fff !important; }
.ssel-completed{ background: #22c55e !important; color: #fff !important; }
.ssel-hold     { background: #ef4444 !important; color: #fff !important; }
.ssel-slitting { background: #f97316 !important; color: #fff !important; }
.ssel-pending  { background: #94a3b8 !important; color: #fff !important; }
.ssel-printingdone { background: #0d9488 !important; color: #fff !important; }
/* ── Column header drag ── */
.planning-board-table th[data-col-key] { cursor: grab; user-select: none; }
.planning-board-table th[data-col-key].col-drag-over { background: #dbeafe; outline: 2px dashed #3b82f6; outline-offset: -2px; }
.planning-board-table th[data-col-key].col-dragging { opacity: .4; }
/* ── Row background colour by status ── */
.row-s-running td, .row-s-running .sticky-col   { background: #eff6ff !important; }
.row-s-completed td, .row-s-completed .sticky-col{ background: #f0fdf4 !important; }
.row-s-hold td, .row-s-hold .sticky-col          { background: #fff5f5 !important; }
.row-s-slitting td, .row-s-slitting .sticky-col  { background: #fff7ed !important; }
.row-s-pending td, .row-s-pending .sticky-col    { background: #fff    !important; }
.row-s-printingdone td, .row-s-printingdone .sticky-col { background: #f0fdfa !important; }
/* ── Status pill badge ── */
.status-pill { display: inline-block; font-size: .75rem; font-weight: 700; padding: 3px 14px; border-radius: 4px; letter-spacing: .03em; text-transform: uppercase; white-space: nowrap; color: #fff; }
.status-pill-running          { background: #3b82f6; }
.status-pill-completed        { background: #22c55e; }
.status-pill-hold,
.status-pill-holdforpayment,
.status-pill-holdforapproval  { background: #ef4444; }
.status-pill-slitting,
.status-pill-preparingslitting { background: #f97316; }
.status-pill-pending          { background: #94a3b8; }
.status-pill-printingdone     { background: #0d9488; }
/* Double-click hint cursor on data cells */
.planning-board-table tbody tr[data-id]:not(.is-editing) td:not(.sticky-col):not(.seq-drag-col) { cursor: pointer; }
/* ── Priority pill badge ── */
.priority-pill { display: inline-block; font-size: .75rem; font-weight: 700; padding: 3px 14px; border-radius: 4px; letter-spacing: .03em; text-transform: uppercase; white-space: nowrap; color: #fff; }
.priority-pill-low { background: #94a3b8; }
.priority-pill-normal { background: #3b82f6; }
.priority-pill-high { background: #f97316; }
.priority-pill-urgent { background: #ef4444; animation: pulse-urgent 1.5s ease-in-out infinite; }
@keyframes pulse-urgent { 0%,100%{ opacity:1; } 50%{ opacity:.78; } }
/* ── Priority select inline edit ── */
.cell-select-priority { -webkit-appearance: none; appearance: none; font-size: .78rem; font-weight: 700; text-align: center; border-radius: 4px !important; padding: 3px 14px !important; cursor: pointer; min-width: 100px; border-width: 0 !important; }
.psel-low     { background: #94a3b8 !important; color: #fff !important; }
.psel-normal  { background: #3b82f6 !important; color: #fff !important; }
.psel-high    { background: #f97316 !important; color: #fff !important; }
.psel-urgent  { background: #ef4444 !important; color: #fff !important; }
/* ── Row drag-to-reorder ── */
.seq-drag-col { width: 28px; min-width: 28px; max-width: 28px; text-align: center; padding: 4px 2px !important; }
.seq-drag-handle { cursor: grab; color: #94a3b8; font-size: 1.1rem; user-select: none; }
.seq-drag-handle:hover { color: #3b82f6; }
.seq-drag-handle:active { cursor: grabbing; }
.row-dragging { opacity: .35; }
.row-dragging td { background: #dbeafe !important; }
.row-drag-over { outline: 2px dashed #3b82f6; outline-offset: -2px; }
.row-drag-over td { background: #eff6ff !important; }
</style>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
