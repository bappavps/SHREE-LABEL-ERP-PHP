// ============================================================
// ERP System — Global UI Script
// ============================================================

/**
 * Shared SQM calculator — reused across Paper Stock & Reports.
 * SQM = (Width_mm × Length_mtr) / 1000
 * Returns 0 if inputs are non-numeric.
 */
window.erpCalcSQM = function(widthMm, lengthMtr) {
    var w = parseFloat(widthMm) || 0;
    var l = parseFloat(lengthMtr) || 0;
    return (w > 0 && l > 0) ? (w / 1000) * l : 0;
};

(function () {
    'use strict';

    // Auto-dismiss flash alerts after 5 seconds
    document.querySelectorAll('.alert').forEach(function (el) {
        var btn = el.querySelector('.alert-close');
        if (btn) {
            btn.addEventListener('click', function () { el.remove(); });
        }
        setTimeout(function () { if (el.isConnected) el.remove(); }, 5000);
    });

    // Mobile sidebar toggle
    var toggleBtn = document.getElementById('sidebarToggle');
    var sidebar   = document.querySelector('.sidebar');
    var appShell  = document.querySelector('.app-shell');
    if (toggleBtn && sidebar && appShell) {
        var collapseTimer = null;

        function collapseSidebarNow() {
            if (window.innerWidth <= 900) {
                sidebar.classList.remove('is-open');
            } else {
                appShell.classList.add('sidebar-collapsed');
                localStorage.setItem('erp_sidebar_collapsed', '1');
            }
        }

        // Desktop default: collapsed sidebar for wider workspace after login.
        // Persist user preference across page loads.
        var sidebarPref = localStorage.getItem('erp_sidebar_collapsed');
        if (window.innerWidth > 900) {
            if (sidebarPref === null || sidebarPref === '1') {
                appShell.classList.add('sidebar-collapsed');
            } else {
                appShell.classList.remove('sidebar-collapsed');
            }
        }

        toggleBtn.addEventListener('click', function () {
            if (window.innerWidth <= 900) {
                sidebar.classList.toggle('is-open');
            } else {
                appShell.classList.toggle('sidebar-collapsed');
                localStorage.setItem('erp_sidebar_collapsed', appShell.classList.contains('sidebar-collapsed') ? '1' : '0');
            }
        });
        document.addEventListener('click', function (e) {
            if (window.innerWidth <= 900
                && sidebar.classList.contains('is-open')
                && !sidebar.contains(e.target)
                && !toggleBtn.contains(e.target)) {
                sidebar.classList.remove('is-open');
            }
        });
        window.addEventListener('resize', function () {
            if (window.innerWidth > 900) {
                sidebar.classList.remove('is-open');
                var pref = localStorage.getItem('erp_sidebar_collapsed');
                if (pref === null || pref === '1') {
                    appShell.classList.add('sidebar-collapsed');
                } else {
                    appShell.classList.remove('sidebar-collapsed');
                }
            }
        });

        // If previous page click requested delayed collapse, apply it after load.
        if (sessionStorage.getItem('erp_collapse_after_nav') === '1') {
            sessionStorage.removeItem('erp_collapse_after_nav');
            collapseTimer = setTimeout(function () {
                collapseSidebarNow();
                collapseTimer = null;
            }, 2000);
        }

        // Auto-collapse on real sidebar page navigation.
        // Ignore accordion toggles that use # links.
        sidebar.addEventListener('click', function (e) {
            var link = e.target.closest('a[href]');
            if (!link) return;

            var href = (link.getAttribute('href') || '').trim();
            if (!href || href === '#') return;
            if (link.classList.contains('nav-group-toggle') || link.classList.contains('nav-sub-parent-toggle')) return;

            if (collapseTimer) {
                clearTimeout(collapseTimer);
                collapseTimer = null;
            }

            // Delay collapse until next page load so navigation remains smooth.
            sessionStorage.setItem('erp_collapse_after_nav', '1');
        });
    }

    // Topbar controls
    var fullscreenBtn = document.getElementById('topbarFullscreenBtn');
    if (fullscreenBtn) {
        fullscreenBtn.addEventListener('click', function () {
            if (!document.fullscreenElement) {
                if (document.documentElement.requestFullscreen) {
                    document.documentElement.requestFullscreen();
                }
            } else if (document.exitFullscreen) {
                document.exitFullscreen();
            }
        });
    }

    function redirectFromButton(btnId) {
        var btn = document.getElementById(btnId);
        if (!btn) return;
        btn.addEventListener('click', function () {
            var href = btn.getAttribute('data-href');
            if (href) window.location.href = href;
        });
    }
    redirectFromButton('topbarProfileBtn');
    redirectFromButton('topbarPowerBtn');

    // Topbar notifications (department-wise)
    (function () {
        var notifBtn = document.getElementById('topbarNotificationBtn');
        var notifDot = document.getElementById('topbarNotificationDot');
        var notifPanel = document.getElementById('topbarNotificationPanel');
        var notifList = document.getElementById('topbarNotificationList');
        var markAllBtn = document.getElementById('topbarNotifMarkAll');
        if (!notifBtn || !notifDot || !notifPanel || !notifList || !markAllBtn) return;

        var apiBase = notifBtn.getAttribute('data-notif-api') || '';
        if (!apiBase) return;
        var fallbackHref = notifBtn.getAttribute('data-href') || '';

        var departments = (notifBtn.getAttribute('data-notif-departments') || '').trim();
        var csrfMeta = document.querySelector('meta[name="csrf-token"]');
        var csrfToken = csrfMeta ? (csrfMeta.getAttribute('content') || '') : '';
        var pollingTimer = null;

        function escHtml(v) {
            return String(v || '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }

        function timeAgo(ts) {
            if (!ts) return '';
            var d = new Date(ts.replace(' ', 'T'));
            if (isNaN(d.getTime())) return '';
            var sec = Math.max(1, Math.floor((Date.now() - d.getTime()) / 1000));
            if (sec < 60) return sec + ' sec ago';
            var min = Math.floor(sec / 60);
            if (min < 60) return min + ' min ago';
            var hr = Math.floor(min / 60);
            if (hr < 24) return hr + ' hr ago';
            var day = Math.floor(hr / 24);
            return day + ' day ago';
        }

        function appBasePrefix() {
            var source = apiBase || fallbackHref || window.location.pathname || '';
            var match = source.match(/^(.*?)(?:\/modules\/|$)/i);
            if (!match) return '';
            return match[1] || '';
        }

        function withAppBase(path) {
            var cleanPath = String(path || '').replace(/^\/+/, '');
            var base = appBasePrefix().replace(/\/+$/, '');
            return (base ? base : '') + '/' + cleanPath;
        }

        function buildDeptUrl(dept) {
            if (dept === 'jumbo_slitting') return withAppBase('modules/operators/jumbo/index.php');
            if (dept === 'flexo_printing') return withAppBase('modules/operators/printing/index.php');
            if (dept === 'flatbed') return withAppBase('modules/operators/flatbed/index.php');
            if (dept === 'rotery') return withAppBase('modules/operators/rotery/index.php');
            if (dept === 'label_slitting') return withAppBase('modules/operators/label-slitting/index.php');
            if (dept === 'packing') return withAppBase('modules/operators/packing/index.php');
            if (dept === 'planning') return withAppBase('modules/planning/index.php');
            return withAppBase('modules/approval/index.php');
        }

        function fetchNotifications(unreadOnly, done) {
            var url = apiBase + '?action=get_notifications&limit=25';
            if (unreadOnly) url += '&unread=1';
            if (departments) url += '&departments=' + encodeURIComponent(departments);

            fetch(url, { credentials: 'same-origin' })
                .then(function (r) { return r.ok ? r.json() : null; })
                .then(function (res) {
                    if (!res || !res.ok) return;
                    var unread = parseInt(res.unread_count || 0, 10) || 0;
                    notifDot.style.display = unread > 0 ? 'inline-block' : 'none';
                    if (typeof done === 'function') done(res.notifications || []);
                })
                .catch(function () {
                    // Ignore silently when jobs API is not accessible for this role.
                });
        }

        function renderList(items) {
            if (!items || !items.length) {
                notifList.innerHTML = '<div class="np-empty">No notifications</div>';
                return;
            }
            notifList.innerHTML = items.map(function (n) {
                var title = (n.job_no || n.department || 'Notification');
                return '' +
                    '<div class="np-item" data-nid="' + escHtml(n.id) + '" data-dept="' + escHtml(n.department || '') + '">' +
                    '<div class="np-item-title">' + escHtml(title) + '</div>' +
                    '<div class="np-item-msg">' + escHtml(n.message || '') + '</div>' +
                    '<div class="np-item-time">' + escHtml(timeAgo(n.created_at)) + '</div>' +
                    '</div>';
            }).join('');
        }

        function markRead(notificationId, cb) {
            if (!csrfToken) {
                if (typeof cb === 'function') cb();
                return;
            }
            var body = new URLSearchParams();
            body.set('csrf_token', csrfToken);
            if (notificationId) {
                body.set('notification_id', String(notificationId));
            } else if (departments) {
                body.set('departments', departments);
            }
            fetch(apiBase + '?action=mark_notification_read', {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: body.toString()
            }).finally(function () {
                if (typeof cb === 'function') cb();
            });
        }

        notifBtn.addEventListener('click', function (e) {
            e.preventDefault();
            var open = notifPanel.style.display === 'block';
            notifPanel.style.display = open ? 'none' : 'block';
            if (!open) {
                fetchNotifications(false, function (rows) { renderList(rows); });
            }
        });

        markAllBtn.addEventListener('click', function () {
            markRead(0, function () {
                fetchNotifications(false, function (rows) { renderList(rows); });
            });
        });

        notifList.addEventListener('click', function (e) {
            var item = e.target.closest('.np-item');
            if (!item) return;
            var nid = parseInt(item.getAttribute('data-nid') || '0', 10) || 0;
            var dept = (item.getAttribute('data-dept') || '').trim();
            markRead(nid, function () {
                window.location.href = buildDeptUrl(dept);
            });
        });

        document.addEventListener('click', function (e) {
            if (!notifPanel.contains(e.target) && !notifBtn.contains(e.target)) {
                notifPanel.style.display = 'none';
            }
        });

        fetchNotifications(true);
        pollingTimer = setInterval(function () { fetchNotifications(true); }, 20000);
        window.addEventListener('beforeunload', function () {
            if (pollingTimer) clearInterval(pollingTimer);
        });
    })();

    // Live topbar date and time
    var dateTimeNode = document.getElementById('topbarDateTime');
    function updateDateTime() {
        if (!dateTimeNode) return;
        var now = new Date();
        dateTimeNode.textContent = now.toLocaleString('en-IN', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
        });
    }
    if (dateTimeNode) {
        updateDateTime();
        setInterval(updateDateTime, 1000);
    }

    // Sidebar accordion behavior
    var groups = Array.prototype.slice.call(document.querySelectorAll('.nav-group'));
    var accordion = groups.map(function (group) {
        return {
            group: group,
            toggle: group.querySelector('.nav-group-toggle'),
            sub: group.querySelector('.nav-sub')
        };
    }).filter(function (x) { return x.toggle && x.sub; });

    function closeAllAccordion() {
        accordion.forEach(function (item) {
            item.group.classList.remove('is-open');
            item.toggle.setAttribute('aria-expanded', 'false');
        });
    }

    // Open the current section if one of its submenu links is active
    var currentPath = window.location.pathname.replace(/\/$/, '');
    accordion.forEach(function (item) {
        var hasActiveClass = item.group.querySelector('.nav-sub-item.active');
        var hasPathMatch = Array.prototype.some.call(item.group.querySelectorAll('.nav-sub-item[href]'), function (link) {
            var href = (link.getAttribute('href') || '').replace(/\/$/, '');
            return href && currentPath.indexOf(href) !== -1;
        });

        if (hasActiveClass || hasPathMatch) {
            item.group.classList.add('is-open');
            item.toggle.setAttribute('aria-expanded', 'true');
        } else {
            item.toggle.setAttribute('aria-expanded', 'false');
        }

        item.toggle.addEventListener('click', function (e) {
            e.preventDefault();
            var wasOpen = item.group.classList.contains('is-open');
            closeAllAccordion();
            if (!wasOpen) {
                item.group.classList.add('is-open');
                item.toggle.setAttribute('aria-expanded', 'true');
            }
        });
    });

    // Nested accordion under Physical Stock Check
    var nested = Array.prototype.slice.call(document.querySelectorAll('.nav-sub-nest'));
    nested.forEach(function (node) {
        var toggle = node.querySelector('.nav-sub-parent-toggle');
        var children = node.querySelector('.nav-sub-children');
        if (!toggle || !children) return;

        var hasActiveChild = node.querySelector('.nav-sub-item.active') ||
            Array.prototype.some.call(node.querySelectorAll('.nav-sub-item[href]'), function (link) {
                var href = (link.getAttribute('href') || '').replace(/\/$/, '');
                return href && currentPath.indexOf(href) !== -1;
            });

        if (hasActiveChild) {
            node.classList.add('is-open');
            toggle.setAttribute('aria-expanded', 'true');
        } else {
            toggle.setAttribute('aria-expanded', 'false');
        }

        toggle.addEventListener('click', function (e) {
            e.preventDefault();
            var isOpen = node.classList.toggle('is-open');
            toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        });
    });

    // Confirm delete
    document.querySelectorAll('[data-confirm]').forEach(function (el) {
        el.addEventListener('click', function (e) {
            if (!confirm(el.getAttribute('data-confirm') || 'Are you sure?')) {
                e.preventDefault();
            }
        });
    });

    // Auto-calculate SQM when width/length changes
    function calcSQM() {
        var w = parseFloat(document.getElementById('width_mm')  && document.getElementById('width_mm').value)  || 0;
        var l = parseFloat(document.getElementById('length_mtr') && document.getElementById('length_mtr').value) || 0;
        var out = document.getElementById('sqm_display');
        if (out) out.textContent = ((w / 1000) * l).toFixed(2);
        var inp = document.getElementById('sqm');
        if (inp) inp.value = ((w / 1000) * l).toFixed(4);
    }
    ['width_mm','length_mtr'].forEach(function (id) {
        var el = document.getElementById(id);
        if (el) el.addEventListener('input', calcSQM);
    });

    // Estimate cost calculator
    function calcEstimate() {
        var labelLen  = parseFloat(document.getElementById('label_length_mm')  && document.getElementById('label_length_mm').value)  || 0;
        var labelW    = parseFloat(document.getElementById('label_width_mm')   && document.getElementById('label_width_mm').value)   || 0;
        var qty       = parseInt(document.getElementById('quantity')           && document.getElementById('quantity').value)         || 0;
        var matRate   = parseFloat(document.getElementById('material_rate')    && document.getElementById('material_rate').value)    || 0;
        var printRate = parseFloat(document.getElementById('printing_rate')    && document.getElementById('printing_rate').value)    || 0;
        var margin    = parseFloat(document.getElementById('margin_pct')       && document.getElementById('margin_pct').value)       || 20;
        var waste     = parseFloat(document.getElementById('waste_factor')     && document.getElementById('waste_factor').value)     || 1.15;

        var sqmPerLabel = (labelLen / 1000) * (labelW / 1000);
        var sqmReq      = sqmPerLabel * qty * waste;
        var matCost     = sqmReq * matRate;
        var printCost   = sqmReq * printRate;
        var totalCost   = matCost + printCost;
        var sellPrice   = totalCost * (1 + margin / 100);
        var pricePerPcs = qty > 0 ? sellPrice / qty : 0;

        function setVal(id, val) {
            var el = document.getElementById(id);
            if (el) {
                if (el.tagName === 'INPUT') el.value = val;
                else el.textContent = val;
            }
        }

        setVal('sqm_required',   sqmReq.toFixed(4));
        setVal('sqm_display',    sqmReq.toFixed(2));
        setVal('material_cost',  matCost.toFixed(2));
        setVal('printing_cost',  printCost.toFixed(2));
        setVal('total_cost',     totalCost.toFixed(2));
        setVal('selling_price',  sellPrice.toFixed(2));
        setVal('price_per_pcs_display', pricePerPcs.toFixed(4));
    }

    ['label_length_mm','label_width_mm','quantity','material_rate',
     'printing_rate','margin_pct','waste_factor'].forEach(function (id) {
        var el = document.getElementById(id);
        if (el) el.addEventListener('input', calcEstimate);
    });

    // Number formatting display (no-op on hidden inputs, only on display spans)
    document.querySelectorAll('[data-format-number]').forEach(function (el) {
        var raw = parseFloat(el.textContent);
        if (!isNaN(raw)) el.textContent = raw.toLocaleString('en-IN', {maximumFractionDigits: 2});
    });

    // Inline search / filter for tables
    var tableSearch = document.getElementById('tableSearch');
    if (tableSearch) {
        tableSearch.addEventListener('input', function () {
            var val = this.value.toLowerCase();
            document.querySelectorAll('[data-table-body] tr').forEach(function (row) {
                row.style.display = row.textContent.toLowerCase().includes(val) ? '' : 'none';
            });
        });
    }

}());
